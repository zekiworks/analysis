#!/usr/bin/env python3
"""Run each frozen proposal once per scheduled slot, preserving every outcome."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import random
import subprocess
import threading
import time
import urllib.error
import urllib.request
import uuid

from fetch_sources import ROOT, NoRedirect, save

ENDPOINTS = {"jev": "https://api.typesafe.ai/v1/systemone",
             "gpt": "https://chatgpt.com/backend-api/codex/responses"}
MAX_RESPONSE_BYTES = 8 * 1024 * 1024


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key")
        result[key] = value
    return result


def usage_and_cost(backend, response, protocol):
    usage = response.get("usage") if isinstance(response, dict) else None
    if not isinstance(usage, dict):
        return {"usage": None, "estimated_usd": None, "usage_complete": False}
    input_tokens, output_tokens = usage.get("input_tokens"), usage.get("output_tokens")
    cached = usage.get("input_tokens_details", {}).get("cached_tokens") if backend == "gpt" else None
    reasoning = usage.get("output_tokens_details", {}).get("reasoning_tokens")
    valid = all(type(value) is int and value >= 0 for value in (input_tokens, output_tokens))
    if cached is not None:
        valid = valid and type(cached) is int and 0 <= cached <= input_tokens
    # The Jev tariff is flat input pricing. GPT cached input must be reported
    # to distinguish its two tariffs; absent cache metadata is not guessed.
    complete = valid and (backend == "jev" or cached is not None)
    price = protocol[backend]
    cost = None
    if complete:
        charged_cached = cached or 0
        cost = ((input_tokens - charged_cached) * price["input_usd_per_million"] +
                charged_cached * price["cached_input_usd_per_million"] +
                output_tokens * price["output_usd_per_million"]) / 1_000_000
    return {"usage": {"input_tokens": input_tokens, "cached_input_tokens": cached,
                      "output_tokens": output_tokens, "reasoning_tokens": reasoning},
            "estimated_usd": cost, "usage_complete": complete}


def parse_jev(response):
    if response.get("model") != "jev-1.13.0" or set(response.get("answers", {})) != {"permission"}:
        raise ValueError("Unexpected Jev model or question identifiers")
    answer = response["answers"]["permission"]
    if answer.get("type") != "choice" or answer.get("choice") not in ("approved", "disapproved"):
        raise ValueError("Unexpected Jev decision type or choice")
    probabilities = answer.get("probabilities", {})
    if set(probabilities) != {"approved", "disapproved"} or not all(
        type(p) in (int, float) and math.isfinite(p) and 0 <= p <= 1 for p in probabilities.values()
    ):
        raise ValueError("Invalid Jev binary probabilities")
    return answer["choice"]


def parse_gpt(response):
    if response.get("status") != "completed":
        raise ValueError("GPT response did not complete")
    output = response.get("output", [])
    if any(item.get("type") not in ("reasoning", "message") for item in output):
        raise ValueError("Unexpected GPT output item; no tools are permitted")
    text = "".join(part.get("text", "") for item in output if item.get("type") == "message"
                   for part in item.get("content", []) if part.get("type") == "output_text")
    value = json.loads(text, object_pairs_hook=unique_object)
    if not isinstance(value, dict) or set(value) != {"verdict"} or value["verdict"] not in ("approved", "disapproved"):
        raise ValueError("GPT did not return the exact binary verdict object")
    return value["verdict"]


class Judges:
    def __init__(self, protocol, manifest_hash, protocol_hash, packets):
        self.protocol = protocol
        self.manifest_hash = manifest_hash
        self.protocol_hash = protocol_hash
        self.packets = packets
        self.stop = threading.Event()
        self.cooldown_lock = threading.Lock()
        self.cooldown = {backend: 0.0 for backend in ENDPOINTS}
        self.jev_key = os.environ.get("JEV_API_KEY", "")
        if not self.jev_key.strip():
            raise ValueError("JEV_API_KEY is required")
        credential_read = subprocess.run(
            ["limactl", "shell", "--workdir", "/workspace/qfork", "default", "cat",
             "/home/cbasaran.guest/.qfork/glyph/credentials/openai.json"],
            capture_output=True, check=True, timeout=30, text=True)
        envelope = json.loads(credential_read.stdout)
        credential = envelope["revisions"][envelope["activeRevision"]]
        if credential["authentication"] != "o_auth":
            raise ValueError("The native OpenAI profile must use OAuth")
        self.expires_at = credential["expiresAtUs"] / 1_000_000
        if self.expires_at <= time.time() + 3600:
            raise ValueError("Refresh the native OpenAI profile before starting this phase")
        self.oauth_secret = credential["secret"]
        self.gpt_headers = {"Authorization": "Bearer " + self.oauth_secret,
                            "Content-Type": "application/json", "Accept": "text/event-stream",
                            "OAI-Product-Sku": "codex"}
        account = credential.get("metadata", {}).get("account_id")
        if account:
            self.gpt_headers["ChatGPT-Account-Id"] = account
        for backend, endpoint in ENDPOINTS.items():
            if protocol[backend]["endpoint"] != endpoint:
                raise ValueError("Refusing an unexpected credential destination")

    def persist(self, path, value):
        text = json.dumps(value, ensure_ascii=False)
        for secret in (self.jev_key, self.oauth_secret):
            text = text.replace(secret, "[REDACTED]")
        save(path, json.loads(text))

    def wait_cooldown(self, backend):
        while not self.stop.is_set():
            with self.cooldown_lock:
                delay = self.cooldown[backend] - time.monotonic()
            if delay <= 0:
                return
            self.stop.wait(min(delay, 1))

    def read_gpt_stream(self, response):
        completed_items, data_lines, total_bytes = [], [], 0
        for raw in response:
            total_bytes += len(raw)
            if total_bytes > MAX_RESPONSE_BYTES:
                raise ValueError("GPT stream exceeds the response bound")
            line = raw.decode("utf-8").rstrip("\r\n")
            if line.startswith("data:"):
                data_lines.append(line[5:].lstrip(" "))
            elif not line and data_lines:
                data = "\n".join(data_lines)
                data_lines.clear()
                if data == "[DONE]":
                    continue
                event = json.loads(data)
                kind = event.get("type")
                if kind == "response.output_item.done":
                    completed_items.append(event["item"])
                elif kind in ("response.completed", "response.failed", "response.incomplete"):
                    value = event["response"]
                    if not value.get("output"):
                        value["output"] = completed_items
                    return value
                elif kind == "error":
                    return {"status": "failed", "error": event, "output": completed_items}
        raise ValueError("GPT stream ended without a terminal response event")

    def call(self, case, repetition, stage, proposal, backend):
        path = ROOT / "receipts" / f"q{case['number']:02d}" / f"r{repetition:03d}" / f"s{stage:02d}-{backend}.json"
        if path.exists():
            previous = json.loads(path.read_text())
            if (previous["packet_id"] != proposal["packet_id"] or previous["manifest_sha256"] != self.manifest_hash or
                    previous["protocol_sha256"] != self.protocol_hash):
                raise ValueError("Existing receipt belongs to different controls")
            if previous["status"] == "running":
                previous.update(status="interrupted", elapsed_seconds=None,
                                error="Process ended with an in-flight request; not silently reissued",
                                request_may_have_completed=True, usage=None, estimated_usd=None, usage_complete=False)
                self.persist(path, previous)
            return previous
        self.wait_cooldown(backend)
        if self.stop.is_set():
            return None
        if time.time() >= self.expires_at - 300:
            self.stop.set()
            raise RuntimeError("OAuth profile needs refresh; remaining slots were not attempted")
        session = str(uuid.uuid4())
        packet = self.packets[proposal["packet_id"]]
        if backend == "jev":
            body = packet["jev_body"]
            headers = {"Authorization": "Bearer " + self.jev_key, "Content-Type": "application/json",
                       "Accept": "application/json"}
        else:
            body = json_bytes({**packet["gpt_template"], "prompt_cache_key": session})
            headers = {**self.gpt_headers, "session_id": session, "conversation_id": session}
        request = urllib.request.Request(ENDPOINTS[backend], data=body, headers=headers, method="POST")
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
        row = {"schema": 1, "question_number": case["number"], "instance_id": case["instance_id"],
               "repetition": repetition, "stage": stage, "backend": backend,
               "packet_id": proposal["packet_id"], "manifest_sha256": self.manifest_hash,
               "protocol_sha256": self.protocol_hash, "request_body_sha256": sha(body),
               "request_uuid": session, "model_requested": self.protocol[backend]["model"],
               "status": "running", "verdict": None, "provider_requests": 1,
               "automatic_retries": 0, "tools_offered": 0, "started_at": utc_now()}
        self.persist(path, row)
        started = time.perf_counter()
        value = None
        try:
            with opener.open(request, timeout=self.protocol["socket_timeout_seconds"]) as response:
                row["http_status"] = response.status
                if backend == "jev":
                    data = response.read(65537)
                    if len(data) > 65536:
                        raise ValueError("Jev response exceeds the native 64 KiB bound")
                    value = json.loads(data)
                    row["verdict"] = parse_jev(value)
                else:
                    value = self.read_gpt_stream(response)
                    row["verdict"] = parse_gpt(value)
                row["status"] = "ok"
        except urllib.error.HTTPError as error:
            row.update(status="http_error", http_status=error.code,
                       error=error.read(65536).decode("utf-8", errors="replace"))
            if error.code in (401, 403):
                self.stop.set()
            if error.code == 429:
                try:
                    delay = max(1.0, float(error.headers.get("Retry-After", "30")))
                except ValueError:
                    delay = 30.0
                with self.cooldown_lock:
                    self.cooldown[backend] = max(self.cooldown[backend], time.monotonic() + delay)
                row["future_request_cooldown_seconds"] = delay
        except (ValueError, KeyError, TypeError) as error:
            provider_failed = isinstance(value, dict) and value.get("status") in ("failed", "incomplete")
            row.update(status="provider_error" if provider_failed else "invalid_response",
                       error=f"{type(error).__name__}: {error}")
        except Exception as error:
            row.update(status="transport_error", error=f"{type(error).__name__}: {error}")
        row.update(elapsed_seconds=time.perf_counter() - started, finished_at=utc_now())
        if isinstance(value, dict):
            row["provider_response"] = value if backend == "jev" else {
                key: value.get(key) for key in ("id", "model", "status", "output", "usage", "error", "incomplete_details")}
            row["model_observed"] = value.get("model")
            row["tool_output_items"] = sum(item.get("type") not in ("reasoning", "message") for item in value.get("output", [])) if backend == "gpt" else 0
        row.update(usage_and_cost(backend, value, self.protocol))
        self.persist(path, row)
        return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=("smoke", "remaining"), required=True)
    args = parser.parse_args()
    os.umask(0o077)
    lock = (ROOT / ".run.lock").open("a")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    manifest_data = (ROOT / "package/manifest.json").read_bytes()
    manifest = json.loads(manifest_data)
    protocol_data = (ROOT / "protocol.json").read_bytes()
    protocol = json.loads(protocol_data)
    if manifest["status"] != "frozen":
        raise SystemExit("Only a frozen package can be judged")
    for name, expected in manifest["input_sha256"].items():
        if sha((ROOT / name).read_bytes()) != expected:
            raise SystemExit("Frozen input changed: " + name)
    if manifest["repetitions"] != protocol["repetitions_per_proposal_per_judge"]:
        raise SystemExit("Repetition controls disagree")
    packets = {}
    for case in manifest["cases"]:
        for proposal in case["proposals"]:
            data = (ROOT / proposal["path"]).read_bytes()
            if sha(data) != proposal["packet_id"]:
                raise SystemExit("Frozen packet changed")
            packet = json.loads(data)
            packets[proposal["packet_id"]] = {
                "jev_body": json_bytes({**packet, "model": protocol["jev"]["model"]}),
                "gpt_template": {"model": protocol["gpt"]["model"], "instructions": protocol["gpt"]["instructions"],
                                 "input": [{"role": "user", "content": [{"type": "input_text", "text":
                                     "Decision packet:\n" + data.decode() + "\n\n" + protocol["gpt"]["deliverable"]}]}],
                                 "tools": [], "store": False, "stream": True,
                                 "reasoning": {"effort": protocol["gpt"]["reasoning_effort"], "summary": "auto"}},
            }
    judges = Judges(protocol, sha(manifest_data), sha(protocol_data), packets)
    repetitions = [1] if args.phase == "smoke" else range(2, manifest["repetitions"] + 1)
    jobs = [(case, repetition) for repetition in repetitions for case in manifest["cases"]]
    random.Random(protocol["scheduling_seed"] + ":" + args.phase).shuffle(jobs)
    launch_id = str(uuid.uuid4())
    launch = {"id": launch_id, "phase": args.phase, "started_at": utc_now(),
              "manifest_sha256": sha(manifest_data), "protocol_sha256": sha(protocol_data),
              "runner_sha256": sha(Path(__file__).read_bytes()), "paired_sequences": len(jobs),
              "max_concurrent_paired_sequences": protocol["concurrent_paired_sequences"],
              "credentials_persisted": False}
    save(ROOT / "launches" / (launch_id + ".json"), launch)
    started = time.perf_counter()
    settled = errors = requests = 0
    workers = protocol["concurrent_paired_sequences"]
    with ThreadPoolExecutor(max_workers=workers * 2) as calls:
        def sequence(case, repetition):
            rows = []
            for stage, proposal in enumerate(case["proposals"], 1):
                if judges.stop.is_set():
                    break
                futures = [calls.submit(judges.call, case, repetition, stage, proposal, backend) for backend in ("jev", "gpt")]
                rows.extend(row for future in futures if (row := future.result()) is not None)
            return rows
        with ThreadPoolExecutor(max_workers=workers) as sequences:
            futures = [sequences.submit(sequence, case, repetition) for case, repetition in jobs]
            for future in as_completed(futures):
                rows = future.result()
                settled += 1
                requests += len(rows)
                errors += sum(row["status"] != "ok" for row in rows)
                if settled % 25 == 0 or settled == len(jobs):
                    print(json.dumps({"phase": args.phase, "settled_sequences": settled, "total_sequences": len(jobs),
                                      "observations": requests, "errors": errors,
                                      "elapsed_seconds": time.perf_counter() - started}), flush=True)
    launch.update(finished_at=utc_now(), elapsed_seconds=time.perf_counter() - started,
                  observations=requests, errors=errors, status="paused" if judges.stop.is_set() else "completed")
    save(ROOT / "launches" / (launch_id + ".json"), launch)
    if judges.stop.is_set():
        raise SystemExit("Authentication paused the experiment; unattempted slots were not counted")


if __name__ == "__main__":
    main()
