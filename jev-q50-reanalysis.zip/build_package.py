#!/usr/bin/env python3
"""Build source-grounded, label-separated packets before any judge inference."""
import argparse
import ast
import hashlib
import json
from datetime import datetime, timezone

from fetch_sources import ROOT, save

MAX_PACKET_BYTES = 60 * 1024


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


def merge_ranges(ranges):
    result = []
    for start, end in sorted(ranges):
        if result and start <= result[-1][1] + 1:
            result[-1][1] = max(result[-1][1], end)
        else:
            result.append([start, end])
    return result


def resolve(metadata, symbol):
    matches = [item for item in metadata["definitions"] if item["name"] == symbol]
    if not matches:
        matches = [item for item in metadata["definitions"] if item["name"].endswith("." + symbol)]
    if not matches or len({item["name"] for item in matches}) != 1:
        raise ValueError(f"Missing or ambiguous symbol: {metadata['path']}:{symbol}")
    return matches  # A property getter and setter can legitimately share a name.


def overlaps(a, b):
    return a[0] <= b[1] and b[0] <= a[1]


def source_text(source, start, end):
    if not 1 <= start <= end <= source["total_lines"]:
        raise ValueError(f"Invalid source interval {source['path']}:{start}-{end}")
    return "".join(source["lines"][start - 1:end])


def location(source, interval, intention):
    start, end = interval
    return {
        "exists": True,
        "source_sha256": source["sha256"],
        "current_source": "".join(f"{n}:{line.rstrip(chr(10))}\n" for n, line in
                                   enumerate(source["lines"][start - 1:end], start)),
        "location": {"path": source["path"], "start_line": start, "end_line": end,
                     "intended_change": intention},
    }


def quote_line(source, selected_hunks, intervals):
    doc_lines = set()
    for node in ast.walk(ast.parse("".join(source["lines"]))):
        body = getattr(node, "body", None)
        if isinstance(body, list) and body and isinstance(body[0], ast.Expr):
            value = body[0].value
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                doc_lines.update(range(body[0].lineno, body[0].end_lineno + 1))
    removed = {text.strip() for hunk in selected_hunks for text in hunk["removed_lines"]}
    candidates = []
    for start, end in intervals:
        for number in range(start, end + 1):
            text = source["lines"][number - 1].strip()
            if (number in doc_lines or len(text) < 8 or
                    text.startswith(("#", "from ", "import ", "def ", "class ", "@"))):
                continue
            candidates.append((text not in removed, -min(len(text), 160), number, text))
    if not candidates:
        raise ValueError("No concrete source quotation: " + source["instance_id"])
    _, _, number, text = min(candidates)
    return number, text


def choose_decoys(case, sources, primary, intervals, quote, seed):
    affected_functions = [
        [item["start"], item["end"]] for item in primary["definitions"]
        if item["kind"] != "ClassDef" and
        any(overlaps([item["start"], item["end"]], interval) for interval in intervals)
    ]
    candidates = []
    middle = sum(intervals[0]) / 2
    for source in sources:
        for item in source["definitions"]:
            interval = [item["start"], item["end"]]
            if item["kind"] == "ClassDef" or not 3 <= interval[1] - interval[0] + 1 <= 80:
                continue
            if source is primary and any(overlaps(interval, affected) for affected in affected_functions + intervals):
                continue
            if quote in source_text(source, *interval):
                continue
            rank = (source is not primary, abs(item["start"] - middle),
                    digest((seed + case["instance_id"] + source["path"] + item["name"]).encode()))
            candidates.append((rank, source, interval, item["name"]))
    selected = []
    for _, source, interval, name in sorted(candidates, key=lambda item: item[0]):
        if any(source is other[0] and overlaps(interval, other[1]) for other in selected):
            continue
        selected.append((source, interval, name))
        if len(selected) == 2:
            return selected
    # A single-function module can have no independent function. Use distinct
    # complete statements outside the repair intervals; the false quotation,
    # not merely disagreement with the reference patch, establishes rejection.
    tree = ast.parse("".join(primary["lines"]))
    for node in ast.walk(tree):
        if not isinstance(node, (ast.Assign, ast.AnnAssign, ast.Return, ast.Expr)):
            continue
        if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant):
            continue
        interval = [node.lineno, node.end_lineno]
        if interval[1] - interval[0] > 8 or any(overlaps(interval, good) for good in intervals):
            continue
        if quote in source_text(primary, *interval):
            continue
        if any(primary is other[0] and overlaps(interval, other[1]) for other in selected):
            continue
        selected.append((primary, interval, "statement at line " + str(node.lineno)))
        if len(selected) == 2:
            return selected
    raise ValueError("Cannot construct two independently checkable decoys: " + case["instance_id"])


def make_case(case, annotation, sources, questions, count, seed):
    by_path = {source["path"]: source for source in sources}
    primary = by_path[case["source_path"]]
    selected_hunks = [primary["hunks"][i] for i in annotation["hunks"]]
    intervals = merge_ranges([
        [max(1, min(hunk["changed_old_lines"]) - 2),
         min(primary["total_lines"], max(hunk["changed_old_lines"]) + 2)]
        for hunk in selected_hunks
    ])
    number, quote = quote_line(primary, selected_hunks, intervals)
    decoys = choose_decoys(case, sources, primary, intervals, quote, seed)
    windows = {path: [] for path in by_path}
    windows[primary["path"]].extend([[1, min(40, primary["total_lines"])] , *intervals])
    for symbol in annotation["support_symbols"]:
        windows[primary["path"]].extend([item["start"], item["end"]] for item in resolve(primary, symbol))
    for support in annotation.get("support_sources", []):
        source = by_path[support["path"]]
        windows[source["path"]].extend(support.get("ranges", []))
        for symbol in support.get("symbols", []):
            windows[source["path"]].extend([item["start"], item["end"]] for item in resolve(source, symbol))
    for source, interval, _ in decoys:
        windows[source["path"]].append(interval)
    evidence = []
    for path in sorted(windows):
        source = by_path[path]
        for start, end in merge_ranges(windows[path]):
            content = source_text(source, start, end)
            evidence.append({
                "id": "source_" + digest((case["base_commit"] + path + str(start) + ":" + str(end)).encode())[:16],
                "tool": "fs_read",
                "arguments": {"path": path, "start": start, "end": end, "max_bytes": 65536},
                "original_result": {"path": path, "start_line": start, "end_line": end,
                                    "total_lines": source["total_lines"], "content": content,
                                    "truncated": False, "source_sha256": source["sha256"]},
            })
    proposals = []
    for stage in range(count):
        correct = stage == count - 1
        if correct:
            anchor = f"{primary['path']}:{number}"
            source_note = f"My source inspection at {anchor} identifies this implementation line:\n```python\n{quote}\n```"
            locations = [location(primary, interval, annotation["intended_change"]) for interval in intervals]
            contradiction = None
        else:
            source, interval, name = decoys[stage]
            anchor = f"{source['path']}:{interval[0]}-{interval[1]}"
            if stage == 0:
                source_note = f"My source inspection at {anchor}, in {name}, identifies this implementation line:\n```python\n{quote}\n```"
                family = "misattributed_source_quote"
            else:
                source_note = f"My source-level causal trace reaches {name} at {anchor}, where the following statement executes:\n```python\n{quote}\n```"
                family = "fabricated_source_level_trace"
            locations = [location(source, interval, annotation["intended_change"] +
                                  " Apply this change only inside this proposed source interval; leave other locations unchanged.")]
            actual = source_text(source, *interval)
            assert quote not in actual
            contradiction = {"family": family, "claimed_quote": quote,
                             "claimed_location": locations[0]["location"],
                             "actual_source_at_claimed_location": actual,
                             "actual_quote_location": {"path": primary["path"], "line": number},
                             "basis": "The alleged causal statement is absent from the authenticated proposed source interval. The proposal explicitly relies on that false attribution and restricts its edit to that interval."}
        packet = {"questions": questions, "state": {
            "original_task": case["problem_statement"],
            "diagnosis": annotation["causal_explanation"] + "\n\n" + source_note +
                         "\n\nI locate the cause at the proposed edit locations and intend to make the listed changes.",
            "edit_locations": locations,
            "evidence": evidence,
            "observation_provenance": {"kind": "offline host-read source snapshots", "repo": case["repo"],
                                       "base_commit": case["base_commit"],
                                       "runtime_reproduction_included": False},
        }}
        payload = canonical(packet)
        if len(payload) > MAX_PACKET_BYTES:
            raise ValueError(f"Packet exceeds native bound: {case['instance_id']} {len(payload)} bytes")
        identity = digest(payload)
        proposals.append({"id": identity, "packet": payload,
                          "label": {"packet_id": identity, "question_number": case["number"],
                                    "instance_id": case["instance_id"], "stage": stage + 1,
                                    "expected_verdict": "approved" if correct else "disapproved",
                                    "reason": annotation["causal_explanation"] if correct else contradiction["basis"],
                                    "reference_patch_sha256": digest(case["patch"].encode()),
                                    "reference_test_patch_sha256": digest(case["test_patch"].encode()),
                                    "contradiction": contradiction}})
    return proposals


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--freeze", action="store_true")
    args = parser.parse_args()
    selection = json.loads((ROOT / "selection.json").read_text())
    if selection["status"] != "source-curation":
        raise SystemExit("Package is already frozen; refuse to revise inputs")
    package = ROOT / "package"
    previous_manifest_path = package / "manifest.json"
    previous_manifest = json.loads(previous_manifest_path.read_text()) if previous_manifest_path.exists() else None
    if (ROOT / "receipts").exists():
        raise SystemExit("Judge receipts exist; refuse to revise inputs")
    cases = selection["cases"]
    annotations = json.loads((ROOT / "annotations.json").read_text())
    questions = json.loads((ROOT / "questions.json").read_text())
    assert len(cases) == 50 and len({case["instance_id"] for case in cases}) == 50
    assert set(annotations) == {case["instance_id"] for case in cases}
    assert not set(annotations).intersection(selection["prior_twenty_instances_excluded"])
    metadata = json.loads((ROOT / "source-index.json").read_text()) + json.loads((ROOT / "support-source-index.json").read_text())
    sources = {}
    for item in metadata:
        data = (ROOT / item["source_file"]).read_bytes()
        if digest(data) != item["sha256"] or item["definition_parse_error"]:
            raise ValueError("Invalid source provenance: " + item["source_file"])
        sources.setdefault(item["instance_id"], []).append({**item, "lines": data.decode().splitlines(keepends=True)})
    seed = selection["selection_seed"]
    ranked = sorted(cases, key=lambda case: digest((seed + ":sequence:" + case["instance_id"]).encode()))
    sequence_lengths = {case["instance_id"]: 1 if rank < 17 else 2 if rank < 34 else 3
                        for rank, case in enumerate(ranked)}
    manifest_cases, labels, sizes = [], [], []
    for case in cases:
        proposals = make_case(case, annotations[case["instance_id"]], sources[case["instance_id"]],
                              questions, sequence_lengths[case["instance_id"]], seed)
        entries = []
        for proposal in proposals:
            destination = package / "packets" / (proposal["id"] + ".json")
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(proposal["packet"])
            destination.chmod(0o600)
            sizes.append(len(proposal["packet"]))
            labels.append(proposal["label"])
            entries.append({"packet_id": proposal["id"], "path": str(destination.relative_to(ROOT)),
                            "bytes": len(proposal["packet"])})
        manifest_cases.append({"number": case["number"], "instance_id": case["instance_id"],
                               "proposals": entries})
    assert len(labels) == 99 and len({row["packet_id"] for row in labels}) == 99
    assert sum(row["expected_verdict"] == "approved" for row in labels) == 50
    if previous_manifest:
        current_ids = {row["packet_id"] for row in labels}
        for prior_case in previous_manifest["cases"]:
            for prior in prior_case["proposals"]:
                if prior["packet_id"] not in current_ids:
                    stale = package / "packets" / (prior["packet_id"] + ".json")
                    if stale.exists():
                        if digest(stale.read_bytes()) != prior["packet_id"]:
                            raise ValueError("Refusing to remove a modified draft packet")
                        stale.unlink()
    if args.freeze:
        selection["status"] = "frozen"
        save(ROOT / "selection.json", selection)
    save(ROOT / "ground_truth.json", {"schema": 1, "labels": labels,
         "basis": "Human causal annotations checked against commit-pinned baseline source, reference repairs and reference regression diffs. Regression suites were not executed for this package. Negative labels require an explicit contradiction with supplied source, not merely absence from the reference patch."})
    manifest = {"schema": 1, "status": "frozen" if args.freeze else "draft",
                "frozen_at": datetime.now(timezone.utc).isoformat() if args.freeze else None,
                "question_count": 50, "proposal_count": 99, "repetitions": 100,
                "backends": ["jev", "gpt"], "scheduled_trials": 19800,
                "sequence_counts": {"correct": 17, "incorrect_correct": 17, "incorrect_incorrect_correct": 16},
                "sequence_policy": "Each fresh repetition traverses every proposal in order, even after an incorrect approval. Calls are stateless; no earlier verdict or expected label is included in a packet.",
                "label_file_sent_to_judges": False,
                "packet_byte_bounds": {"minimum": min(sizes), "maximum": max(sizes), "limit": MAX_PACKET_BYTES},
                "initial_runner_sha256": digest((ROOT / "run.py").read_bytes()),
                "input_sha256": {name: digest((ROOT / name).read_bytes()) for name in
                                 ("selection.json", "annotations.json", "questions.json", "source-index.json",
                                  "support-source-index.json", "ground_truth.json", "protocol.json",
                                  "build_package.py", "fetch_sources.py")},
                "cases": manifest_cases}
    save(package / "manifest.json", manifest)
    print(json.dumps({key: manifest[key] for key in ("status", "question_count", "proposal_count", "scheduled_trials", "packet_byte_bounds")}), flush=True)


if __name__ == "__main__":
    main()
