#!/usr/bin/env python3
"""Score immutable calibration receipts offline; never call a judge or relabel."""
import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import io
import json
import math
import statistics

from fetch_sources import ROOT, save
from run import json_bytes, parse_gpt, parse_jev, sha, usage_and_cost


def percentile(values, probability):
    if not values:
        return None
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lo, hi = math.floor(position), math.ceil(position)
    return ordered[lo] + (ordered[hi] - ordered[lo]) * (position - lo)


def distribution(values):
    return {"n": len(values), "mean": statistics.mean(values) if values else None,
            "p50": percentile(values, .5), "p95": percentile(values, .95),
            "p99": percentile(values, .99), "maximum": max(values) if values else None}


def fraction(numerator, denominator):
    return numerator / denominator if denominator else None


def metrics(rows):
    valid = [row for row in rows if row["status"] == "ok"]
    positives = [row for row in rows if row["expected_verdict"] == "approved"]
    negatives = [row for row in rows if row["expected_verdict"] == "disapproved"]
    correct = sum(row["correct"] for row in rows)
    false_approvals = sum(row["verdict"] == "approved" for row in negatives)
    false_rejections = sum(row["verdict"] == "disapproved" for row in positives)
    prices = [row["estimated_usd"] for row in rows if row["estimated_usd"] is not None]
    token_fields = ("input_tokens", "cached_input_tokens", "output_tokens", "reasoning_tokens")
    tokens = {field: sum((row.get("usage") or {}).get(field) or 0 for row in rows) for field in token_fields}
    reported = {field: sum((row.get("usage") or {}).get(field) is not None for row in rows) for field in token_fields}
    return {"settled_trials": len(rows), "valid_decisions": len(valid), "errors": len(rows) - len(valid),
            "status_counts": dict(Counter(row["status"] for row in rows)),
            "verdict_counts": dict(Counter(row["verdict"] for row in valid)),
            "correct_decisions": correct,
            "accuracy_all_settled_trials": fraction(correct, len(rows)),
            "accuracy_valid_decisions_only": fraction(correct, len(valid)),
            "positive_trials": len(positives), "negative_trials": len(negatives),
            "false_approvals": false_approvals, "false_rejections": false_rejections,
            "false_approval_rate_all_negative_trials": fraction(false_approvals, len(negatives)),
            "false_rejection_rate_all_positive_trials": fraction(false_rejections, len(positives)),
            "positive_approval_rate_all_trials": fraction(sum(row["correct"] for row in positives), len(positives)),
            "negative_rejection_rate_all_trials": fraction(sum(row["correct"] for row in negatives), len(negatives)),
            "error_rate": fraction(len(rows) - len(valid), len(rows)),
            "latency_seconds_all_settled_trials": distribution([row["elapsed_seconds"] for row in rows if row.get("elapsed_seconds") is not None]),
            "latency_seconds_valid_decisions": distribution([row["elapsed_seconds"] for row in valid]),
            "receipt_utc_interval_seconds": distribution([row["utc_elapsed_seconds"] for row in rows if row["utc_elapsed_seconds"] is not None]),
            "clock_gaps_over_one_second": sum(row["clock_gap_seconds"] is not None and abs(row["clock_gap_seconds"]) > 1 for row in rows),
            "observed_estimated_usd": sum(prices), "trials_with_priced_usage": len(prices),
            "usage_complete_for_all_settled_trials": len(prices) == len(rows),
            "mean_observed_usd_per_priced_trial": statistics.mean(prices) if prices else None,
            "observed_cost_per_correct_decision_usd": fraction(sum(prices), correct),
            "reported_token_totals": tokens, "trials_reporting_token_fields": reported,
            "observed_model_counts": dict(Counter(row.get("model_observed") or "unreported" for row in rows)),
            "tool_output_items": sum(row.get("tool_output_items", 0) for row in rows)}


def expected_request_hash(backend, packet_bytes, protocol, request_uuid):
    if backend == "jev":
        return sha(json_bytes({**json.loads(packet_bytes), "model": protocol[backend]["model"]}))
    body = {"model": protocol["gpt"]["model"], "instructions": protocol["gpt"]["instructions"],
            "input": [{"role": "user", "content": [{"type": "input_text", "text":
                "Decision packet:\n" + packet_bytes.decode() + "\n\n" + protocol["gpt"]["deliverable"]}]}],
            "tools": [], "store": False, "stream": True,
            "reasoning": {"effort": protocol["gpt"]["reasoning_effort"], "summary": "auto"},
            "prompt_cache_key": request_uuid}
    return sha(json_bytes(body))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--partial", action="store_true")
    args = parser.parse_args()
    manifest_bytes = (ROOT / "package/manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    protocol_bytes = (ROOT / "protocol.json").read_bytes()
    protocol = json.loads(protocol_bytes)
    truth = json.loads((ROOT / "ground_truth.json").read_text())
    labels = {row["packet_id"]: row for row in truth["labels"]}
    for name, expected in manifest["input_sha256"].items():
        if sha((ROOT / name).read_bytes()) != expected:
            raise ValueError("Frozen input changed: " + name)
    rows, missing, in_flight = [], [], []
    by_sequence = defaultdict(list)
    by_question = defaultdict(list)
    by_proposal = defaultdict(list)
    by_pair = defaultdict(dict)
    unique_requests = set()
    verified_requests = 0
    stage_order_violations = []
    for case in manifest["cases"]:
        for repetition in range(1, manifest["repetitions"] + 1):
            prior_end = {}
            for stage, proposal in enumerate(case["proposals"], 1):
                prior_stage_end = max(prior_end.values(), default=None)
                packet_id = proposal["packet_id"]
                packet_bytes = (ROOT / proposal["path"]).read_bytes()
                if sha(packet_bytes) != packet_id:
                    raise ValueError("Frozen packet changed")
                for backend in manifest["backends"]:
                    path = ROOT / "receipts" / f"q{case['number']:02d}" / f"r{repetition:03d}" / f"s{stage:02d}-{backend}.json"
                    slot = {"question": case["number"], "repetition": repetition, "stage": stage, "backend": backend}
                    if not path.exists():
                        missing.append(slot)
                        continue
                    row = json.loads(path.read_text())
                    if (row["packet_id"] != packet_id or row["manifest_sha256"] != sha(manifest_bytes) or
                            row["protocol_sha256"] != sha(protocol_bytes) or row["backend"] != backend or
                            row["question_number"] != case["number"] or row["repetition"] != repetition or row["stage"] != stage):
                        raise ValueError("Receipt identity mismatch: " + str(path))
                    if row["request_uuid"] in unique_requests:
                        raise ValueError("A request UUID was reused")
                    unique_requests.add(row["request_uuid"])
                    if row["request_body_sha256"] != expected_request_hash(backend, packet_bytes, protocol, row["request_uuid"]):
                        raise ValueError("Provider request differs from the frozen packet or controls")
                    if row["provider_requests"] != 1 or row["automatic_retries"] != 0 or row["tools_offered"] != 0:
                        raise ValueError("Request count or tool contract violated")
                    verified_requests += 1
                    if row["status"] == "running":
                        in_flight.append(slot)
                        continue
                    started = datetime.fromisoformat(row["started_at"])
                    if prior_stage_end is not None and started < prior_stage_end:
                        stage_order_violations.append(slot)
                    if row.get("finished_at"):
                        prior_end[backend] = datetime.fromisoformat(row["finished_at"])
                    row["utc_elapsed_seconds"] = None
                    row["clock_gap_seconds"] = None
                    if row.get("finished_at") and row.get("elapsed_seconds") is not None:
                        row["utc_elapsed_seconds"] = (prior_end[backend] - started).total_seconds()
                        row["clock_gap_seconds"] = row["utc_elapsed_seconds"] - row["elapsed_seconds"]
                    response = row.get("provider_response")
                    if row["status"] == "ok":
                        decision = parse_jev(response) if backend == "jev" else parse_gpt(response)
                        if decision != row["verdict"]:
                            raise ValueError("Saved decision differs from the provider response")
                    recomputed = usage_and_cost(backend, response, protocol)
                    if row["usage"] != recomputed["usage"] or row["estimated_usd"] != recomputed["estimated_usd"]:
                        raise ValueError("Saved usage or cost differs from the raw response")
                    row["expected_verdict"] = labels[packet_id]["expected_verdict"]
                    row["correct"] = row["status"] == "ok" and row["verdict"] == row["expected_verdict"]
                    row["negative_family"] = (labels[packet_id].get("contradiction") or {}).get("family")
                    row["receipt"] = str(path.relative_to(ROOT))
                    rows.append(row)
                    by_question[(case["number"], backend)].append(row)
                    by_sequence[(case["number"], repetition, backend)].append(row)
                    by_proposal[(packet_id, backend)].append(row)
                    by_pair[(packet_id, repetition)][backend] = row
    if not args.partial and (missing or in_flight):
        raise SystemExit(f"Incomplete experiment: {len(missing)} missing, {len(in_flight)} in flight; use --partial for an explicitly partial report")
    if stage_order_violations:
        raise ValueError("Observed proposal stages were not ordered")
    arms = {backend: metrics([row for row in rows if row["backend"] == backend]) for backend in manifest["backends"]}
    proposals = []
    for (packet_id, backend), observations in sorted(by_proposal.items()):
        entry = {"packet_id": packet_id, "backend": backend,
                 "question_number": labels[packet_id]["question_number"],
                 "instance_id": labels[packet_id]["instance_id"], "stage": labels[packet_id]["stage"],
                 "expected_verdict": labels[packet_id]["expected_verdict"], **metrics(observations)}
        counts = entry["verdict_counts"]
        n = entry["valid_decisions"]
        a, d = counts.get("approved", 0), counts.get("disapproved", 0)
        entry["majority_fraction_valid_decisions"] = fraction(max(a, d), n)
        entry["pairwise_disagreement_probability"] = fraction(2 * a * d, n * (n - 1))
        proposals.append(entry)
    sequences = []
    lengths = {case["number"]: len(case["proposals"]) for case in manifest["cases"]}
    for (number, repetition, backend), observations in sorted(by_sequence.items()):
        if len(observations) != lengths[number]:
            continue
        ordered = sorted(observations, key=lambda row: row["stage"])
        approved = next((row for row in ordered if row["status"] == "ok" and row["verdict"] == "approved"), None)
        sequences.append({"question_number": number, "repetition": repetition, "backend": backend,
                          "fully_correct": all(row["correct"] for row in ordered),
                          "has_error": any(row["status"] != "ok" for row in ordered),
                          "first_approval": "none" if approved is None else "correct" if approved["correct"] else "incorrect"})
    for backend in manifest["backends"]:
        selected = [row for row in sequences if row["backend"] == backend]
        arms[backend]["sequence_results"] = {"complete_sequences": len(selected),
            "fully_correct": sum(row["fully_correct"] for row in selected),
            "fully_correct_rate": fraction(sum(row["fully_correct"] for row in selected), len(selected)),
            "sequences_with_errors": sum(row["has_error"] for row in selected),
            "first_approval_counts": dict(Counter(row["first_approval"] for row in selected))}
        selected_proposals = [row for row in proposals if row["backend"] == backend]
        arms[backend]["proposal_consistency"] = {
            "proposals_observed": len(selected_proposals),
            "all_valid_verdicts_identical": sum(row["valid_decisions"] > 0 and len(row["verdict_counts"]) == 1 for row in selected_proposals),
            "variable_verdicts": sum(len(row["verdict_counts"]) > 1 for row in selected_proposals),
            "mean_majority_fraction": statistics.mean(row["majority_fraction_valid_decisions"] for row in selected_proposals if row["valid_decisions"]) if any(row["valid_decisions"] for row in selected_proposals) else None}
    pair_counts = Counter()
    for pair in by_pair.values():
        if set(pair) != {"jev", "gpt"}:
            continue
        if any(row["status"] != "ok" for row in pair.values()):
            pair_counts["one_or_both_errors"] += 1
        elif pair["jev"]["correct"] and pair["gpt"]["correct"]:
            pair_counts["both_correct"] += 1
        elif pair["jev"]["correct"]:
            pair_counts["only_jev_correct"] += 1
        elif pair["gpt"]["correct"]:
            pair_counts["only_gpt_correct"] += 1
        else:
            pair_counts["both_incorrect"] += 1
    question_results = [
        {"question_number": case["number"], "instance_id": case["instance_id"],
         "proposal_count": len(case["proposals"]),
         "arms": {backend: metrics(by_question[(case["number"], backend)])
                  for backend in manifest["backends"]}}
        for case in manifest["cases"]
    ]
    for backend in manifest["backends"]:
        question_rates = [entry["arms"][backend]["accuracy_all_settled_trials"]
                          for entry in question_results if entry["arms"][backend]["settled_trials"]]
        arms[backend]["mean_question_accuracy_all_trials"] = statistics.mean(question_rates) if question_rates else None
    summary = {"schema": 1, "scored_at": datetime.now(timezone.utc).isoformat(),
               "complete": not missing and not in_flight, "question_count": 50, "proposal_count": 99,
               "scheduled_trials": manifest["scheduled_trials"], "settled_trials": len(rows),
               "missing_slots": len(missing), "in_flight_slots": len(in_flight),
               "manifest_sha256": sha(manifest_bytes), "protocol_sha256": sha(protocol_bytes),
               "requests_verified_against_frozen_packets_and_controls": verified_requests,
               "stage_order_violations": stage_order_violations, "arms": arms,
               "paired_trial_results": dict(pair_counts),
               "negative_families": {family: {backend: metrics([row for row in rows if row["negative_family"] == family and row["backend"] == backend]) for backend in manifest["backends"]} for family in ("misattributed_source_quote", "fabricated_source_level_trace")},
               "interpretation": [
                   "Fifty curated public SWE-bench questions, not 9900 independent bugs; repeated calls measure within-packet consistency.",
                   "Positive proposals are author-curated from reference repairs and baseline source. Negative proposals contain explicit source contradictions; this is not accuracy on naturally sampled investigator mistakes.",
                   "Accuracy means agreement with frozen labels. False source attribution does not prove the named location cannot host an alternative repair; these scores are not pure wrong-edit-location accuracy.",
                   "Post-run source review identified alternative-location ambiguity in q08/stage1 and q29/stage1. analysis.json preserves the primary scores and reports an explicitly post-hoc exclusion sensitivity; no labels or requests were changed.",
                   "Reference regression suites were not executed for packet preparation. Source bindings and contradictions were checked before any judge inference.",
                   "Errors are not semantic rejections. All-trial accuracy treats failure to decide as unsuccessful; valid-only accuracy is also reported.",
                   "All stages were scheduled even after an incorrect approval. First-approval sequence metrics are counterfactual gating summaries, not coding-agent or SWE-bench solve rates.",
                   "Primary latency uses the runner's monotonic elapsed clock under eight concurrent paired sequences, not native gate-wrapper latency or isolated model compute time. UTC receipt intervals are exported separately.",
                   "A host sleep overlapped ten trials and explains their roughly 925-second UTC/monotonic gaps. All eight GPT read timeouts overlap that event; do not attribute them solely to provider reliability. See analysis.json.",
                   "Costs are usage-based estimates, not invoices. Missing usage is unknown. Jev does not report cached/reasoning token details; zero reported totals for those fields do not prove zero internal caching/reasoning.",
                   "Both providers received identical complete source evidence packets; provider-internal caching or context handling is not independently observable."
               ]}
    prefix = "partial-" if args.partial else ""
    save(ROOT / (prefix + "summary.json"), summary)
    save(ROOT / (prefix + "proposals.json"), proposals)
    save(ROOT / (prefix + "sequences.json"), sequences)
    save(ROOT / (prefix + "question-comparison.json"), question_results)
    columns = ["question_number", "instance_id", "repetition", "stage", "backend", "packet_id",
               "expected_verdict", "verdict", "status", "correct", "elapsed_seconds", "estimated_usd",
               "input_tokens", "cached_input_tokens", "output_tokens", "reasoning_tokens", "receipt",
               "started_at", "finished_at", "utc_elapsed_seconds", "clock_gap_seconds"]
    stream = io.StringIO()
    writer = csv.DictWriter(stream, fieldnames=columns)
    writer.writeheader()
    for row in sorted(rows, key=lambda value: (value["question_number"], value["repetition"], value["stage"], value["backend"])):
        flattened = {**row, **(row.get("usage") or {})}
        writer.writerow({key: flattened.get(key) for key in columns})
    csv_path = ROOT / (prefix + "decisions.csv")
    csv_path.write_text(stream.getvalue())
    csv_path.chmod(0o600)
    proposal_index = {(entry["packet_id"], entry["backend"]): entry for entry in proposals}
    comparison = []
    for case in manifest["cases"]:
        for stage, proposal in enumerate(case["proposals"], 1):
            packet_id = proposal["packet_id"]
            entry = {"question_number": case["number"], "instance_id": case["instance_id"],
                     "stage": stage, "packet_id": packet_id,
                     "expected_verdict": labels[packet_id]["expected_verdict"]}
            for backend in manifest["backends"]:
                measured = proposal_index.get((packet_id, backend), {})
                for key in ("settled_trials", "valid_decisions", "errors", "correct_decisions",
                            "accuracy_all_settled_trials", "false_approvals", "false_rejections",
                            "observed_estimated_usd", "mean_observed_usd_per_priced_trial",
                            "majority_fraction_valid_decisions"):
                    entry[backend + "_" + key] = measured.get(key)
                for quantile in ("p50", "p95", "p99"):
                    entry[backend + "_latency_" + quantile + "_seconds"] = measured.get("latency_seconds_valid_decisions", {}).get(quantile)
            comparison.append(entry)
    comparison_stream = io.StringIO()
    comparison_writer = csv.DictWriter(comparison_stream, fieldnames=list(comparison[0]))
    comparison_writer.writeheader()
    comparison_writer.writerows(comparison)
    comparison_path = ROOT / (prefix + "comparison.csv")
    comparison_path.write_text(comparison_stream.getvalue())
    comparison_path.chmod(0o600)
    print(json.dumps({"complete": summary["complete"], "settled_trials": len(rows), "missing_slots": len(missing),
                      "arms": {backend: {key: arm[key] for key in ("valid_decisions", "errors", "correct_decisions", "observed_estimated_usd")} for backend, arm in arms.items()}}), flush=True)


if __name__ == "__main__":
    main()
