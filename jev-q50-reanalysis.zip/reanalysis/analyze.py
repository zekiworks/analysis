#!/usr/bin/env python3
"""Offline packet statistics and question-held-out Jev/GPT cascade simulation."""
import argparse
import csv
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from run import parse_gpt, parse_jev, usage_and_cost
from score import distribution

BACKENDS = ("jev", "gpt")
VERDICTS = {"approved": 1, "disapproved": 0, None: -1, "": -1}


def load(path):
    return json.loads(path.read_text())


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_csv(path, rows):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def metadata(manifest, truth, protocol):
    labels = {row["packet_id"]: row for row in truth["labels"]}
    selection = {case["question_number"] for case in protocol["split"]["selection"]}
    test = {case["question_number"] for case in protocol["split"]["test"]}
    assert len(selection) == len(test) == 25 and not selection.intersection(test)
    disputed = {(row["question_number"], row["stage"]) for row in protocol["disputed_packets"]}
    packets = []
    for case in manifest["cases"]:
        assert case["number"] in selection | test
        for stage, proposal in enumerate(case["proposals"], 1):
            label = labels[proposal["packet_id"]]
            packets.append({"packet_id": proposal["packet_id"], "question_number": case["number"],
                            "instance_id": case["instance_id"], "stage": stage,
                            "expected_verdict": label["expected_verdict"],
                            "split": "selection" if case["number"] in selection else "test",
                            "disputed": (case["number"], stage) in disputed})
    assert len(packets) == 99 and sum(p["disputed"] for p in packets) == 2
    return packets


def read_receipts(packets, manifest, provider_protocol):
    manifest_hash = digest((ROOT / "package/manifest.json").read_bytes())
    protocol_hash = digest((ROOT / "protocol.json").read_bytes())
    rows, hashes = [], {}
    for packet in packets:
        for repetition in range(1, manifest["repetitions"] + 1):
            row = {**packet, "repetition": repetition}
            for backend in BACKENDS:
                relative = f"receipts/q{packet['question_number']:02d}/r{repetition:03d}/s{packet['stage']:02d}-{backend}.json"
                raw = (ROOT / relative).read_bytes()
                receipt = json.loads(raw)
                hashes[relative] = digest(raw)
                identity = (receipt["packet_id"], receipt["question_number"], receipt["stage"],
                            receipt["repetition"], receipt["backend"], receipt["manifest_sha256"],
                            receipt["protocol_sha256"])
                assert identity == (packet["packet_id"], packet["question_number"], packet["stage"],
                                    repetition, backend, manifest_hash, protocol_hash)
                response = receipt.get("provider_response")
                if receipt["status"] == "ok":
                    verdict = parse_jev(response) if backend == "jev" else parse_gpt(response)
                    assert verdict == receipt["verdict"]
                else:
                    assert receipt["status"] not in ("running", "interrupted")
                    verdict = None
                priced = usage_and_cost(backend, response, provider_protocol)
                assert priced["usage"] == receipt["usage"]
                assert priced["estimated_usd"] == receipt["estimated_usd"]
                usage = priced["usage"] or {}
                row.update({f"{backend}_status": receipt["status"], f"{backend}_verdict": verdict,
                            f"{backend}_elapsed_seconds": receipt["elapsed_seconds"],
                            f"{backend}_utc_elapsed_seconds": (datetime.fromisoformat(receipt["finished_at"]) -
                                                                datetime.fromisoformat(receipt["started_at"])).total_seconds(),
                            f"{backend}_estimated_usd": priced["estimated_usd"]})
                for field in ("input_tokens", "cached_input_tokens", "output_tokens", "reasoning_tokens"):
                    row[f"{backend}_{field}"] = usage.get(field)
                if backend == "jev":
                    answer = (response or {}).get("answers", {}).get("permission", {})
                    probabilities = answer.get("probabilities", {})
                    row["jev_p_approve"] = probabilities.get("approved")
                    row["jev_p_reject"] = probabilities.get("disapproved")
                    row["jev_confidence"] = answer.get("confidence")
            rows.append(row)
    save(OUT / "input-receipt-sha256.json", hashes)
    write_csv(OUT / "paired-trials.csv", rows)
    return rows


def read_paired(path, packets, repetitions):
    with path.open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    expected = {(p["packet_id"], r): p for p in packets for r in range(1, repetitions + 1)}
    seen = set()
    for row in rows:
        key = (row["packet_id"], int(row["repetition"]))
        if key in seen or key not in expected:
            raise ValueError("Duplicate or unexpected paired trial")
        seen.add(key)
        packet = expected[key]
        for name in ("instance_id", "expected_verdict", "split"):
            assert row[name] == packet[name]
        for name in ("question_number", "stage"):
            assert int(row[name]) == packet[name]
        row.update(packet)
        row["repetition"] = key[1]
        for name in list(row):
            if name.endswith(("_seconds", "_usd", "_tokens")) or name in ("jev_p_approve", "jev_p_reject", "jev_confidence"):
                row[name] = float(row[name]) if row[name] != "" else None
    assert seen == set(expected)
    return rows


def arrays(rows, packets, repetitions):
    by_key = {(row["packet_id"], row["repetition"]): row for row in rows}
    ordered = [[by_key[(packet["packet_id"], r)] for r in range(1, repetitions + 1)] for packet in packets]
    fields = {}
    for backend in BACKENDS:
        fields[backend] = np.array([[VERDICTS[row[f"{backend}_verdict"]] for row in group] for group in ordered])
        for suffix in ("elapsed_seconds", "utc_elapsed_seconds", "estimated_usd"):
            fields[f"{backend}_{suffix}"] = np.array([[row[f"{backend}_{suffix}"] for row in group] for group in ordered], dtype=float)
    for name in ("jev_p_approve", "jev_p_reject", "jev_confidence"):
        fields[name] = np.array([[row[name] for row in group] for group in ordered], dtype=float)
    valid = fields["jev"] >= 0
    assert np.isfinite(fields["jev_p_approve"][valid]).all()
    assert np.isfinite(fields["jev_p_reject"][valid]).all()
    assert np.allclose((fields["jev_p_approve"] + fields["jev_p_reject"])[valid], 1, atol=1e-8, rtol=0)
    assert ((fields["jev_p_approve"][valid] >= 0) & (fields["jev_p_approve"][valid] <= 1)).all()
    fields["score"] = np.where(fields["jev"] == 1, fields["jev_p_approve"], fields["jev_p_reject"])
    fields["expected"] = np.array([VERDICTS[p["expected_verdict"]] for p in packets])[:, None]
    return fields


def packet_statistics(packets, data):
    result = []
    for i, packet in enumerate(packets):
        row = dict(packet)
        for backend in BACKENDS:
            v = data[backend][i]
            a, d, n = int((v == 1).sum()), int((v == 0).sum()), int((v >= 0).sum())
            adjacent = (v[:-1] >= 0) & (v[1:] >= 0)
            majority = "approved" if a > d else "disapproved" if d > a else "tie" if n else "no_decision"
            values = {"approved": a, "disapproved": d, "errors": len(v) - n, "majority": majority,
                      "majority_correct": majority == packet["expected_verdict"],
                      "approval_fraction_valid": a / n if n else None,
                      "minority_fraction_valid": min(a, d) / n if n else None,
                      "pairwise_flip_rate": 2 * a * d / (n * (n - 1)) if n > 1 else None,
                      "adjacent_valid_pairs": int(adjacent.sum()),
                      "adjacent_flip_rate": float((v[:-1][adjacent] != v[1:][adjacent]).mean()) if adjacent.any() else None}
            row.update({f"{backend}_{key}": value for key, value in values.items()})
        for field in ("jev_p_approve", "jev_confidence"):
            values = data[field][i]
            finite = values[np.isfinite(values)]
            row[f"{field}_min"] = float(finite.min()) if len(finite) else None
            row[f"{field}_median"] = float(np.median(finite)) if len(finite) else None
            row[f"{field}_max"] = float(finite.max()) if len(finite) else None
        result.append(row)
    return result


def route(data, threshold):
    autonomous = (data["jev"] >= 0) & (data["score"] >= threshold)
    verdict = np.where(autonomous, data["jev"], data["gpt"])
    return verdict, autonomous


def candidates(scores, valid):
    observed = np.unique(scores[valid & np.isfinite(scores) & (scores >= .5)])
    return np.unique(np.concatenate(([.5, 1.0, np.nextafter(1., np.inf)], observed,
                                     np.nextafter(observed, np.inf))))


def curve(data, indices, thresholds):
    negative = data["expected"][indices] == 0
    negative_trials = int(negative.sum()) * data["jev"].shape[1]
    gpt_fp = int(((data["gpt"][indices] == 1) & negative).sum())
    points = []
    for threshold in thresholds:
        verdict, autonomous = route(data, float(threshold))
        v, auto = verdict[indices], autonomous[indices]
        auto_negative = int((auto & negative).sum())
        auto_fp = int(((data["jev"][indices] == 1) & auto & negative).sum())
        cascade_fp = int(((v == 1) & negative).sum())
        points.append({"threshold": float(threshold), "autonomous_attempts": int(auto.sum()),
                       "attempts": int(auto.size), "coverage": float(auto.mean()),
                       "negative_attempts": negative_trials, "autonomous_negative_attempts": auto_negative,
                       "jev_autonomous_false_approvals": auto_fp,
                       "jev_autonomous_false_approve_rate_all_negatives": auto_fp / negative_trials if negative_trials else None,
                       "jev_autonomous_false_approve_rate_decided_negatives": auto_fp / auto_negative if auto_negative else None,
                       "cascade_false_approvals": cascade_fp,
                       "cascade_false_approve_rate": cascade_fp / negative_trials if negative_trials else None,
                       "gpt_false_approvals": gpt_fp,
                       "gpt_false_approve_rate": gpt_fp / negative_trials if negative_trials else None})
    return points


def select_point(points, counter):
    feasible = [p for p in points if p[counter] <= p["gpt_false_approvals"]]
    if not feasible:
        raise ValueError("The all-defer candidate must reproduce GPT decisions")
    return max(feasible, key=lambda p: (p["autonomous_attempts"], p["threshold"]))


def bootstrap_weights(n, repetitions, seed):
    return np.random.default_rng(seed).multinomial(n, np.full(n, 1 / n), size=repetitions)


def interval(values):
    finite = values[np.isfinite(values)]
    return [float(x) for x in np.quantile(finite, [.025, .975])] if len(finite) else None


def ratio(numerator, denominator):
    denominator = np.asarray(denominator)
    return np.divide(numerator, denominator, out=np.full(np.broadcast_shapes(np.shape(numerator), denominator.shape), np.nan), where=denominator != 0)


def arm_summary(verdict, expected, costs, times, utc_times, weights, autonomous=None):
    valid = verdict >= 0
    negative = np.broadcast_to(expected == 0, verdict.shape)
    positive = ~negative
    approved, rejected = verdict == 1, verdict == 0
    correct = valid & (verdict == expected)
    n = valid.sum(axis=1)
    a, d = approved.sum(axis=1), rejected.sum(axis=1)
    majority = np.where(a > d, 1, np.where(d > a, 0, -1))
    packet_counts = {"attempts": np.full(len(verdict), verdict.shape[1]), "valid": n,
                     "correct": correct.sum(axis=1), "negative": negative.sum(axis=1),
                     "positive": positive.sum(axis=1), "false_approve": (approved & negative).sum(axis=1),
                     "false_reject": (rejected & positive).sum(axis=1),
                     "majority_correct": (majority == expected[:, 0]).astype(int),
                     "negative_packet": negative[:, 0].astype(int),
                     "negative_majority_approve": ((majority == 1) & negative[:, 0]).astype(int)}
    sums = {name: weights @ counts for name, counts in packet_counts.items()}
    distributions = {"agreement_all_attempts": ratio(sums["correct"], sums["attempts"]),
                     "agreement_valid_decisions": ratio(sums["correct"], sums["valid"]),
                     "false_approve_rate": ratio(sums["false_approve"], sums["negative"]),
                     "false_reject_rate": ratio(sums["false_reject"], sums["positive"]),
                     "majority_packet_agreement": sums["majority_correct"] / len(verdict),
                     "negative_majority_approval_rate": ratio(sums["negative_majority_approve"], sums["negative_packet"])}
    flips = ratio(2 * a * d, n * (n - 1))
    distributions["mean_pairwise_flip_rate"] = ratio(weights @ np.nan_to_num(flips), weights @ np.isfinite(flips))
    known_cost = np.nansum(costs, axis=2)
    complete_cost = np.isfinite(costs).all(axis=2)
    distributions["observed_usd_per_attempt"] = (weights @ known_cost.sum(axis=1)) / sums["attempts"]
    distributions["mean_monotonic_seconds"] = (weights @ times.sum(axis=1)) / sums["attempts"]
    distributions["mean_utc_seconds"] = (weights @ utc_times.sum(axis=1)) / sums["attempts"]
    result = {"packets": len(verdict), "attempts": int(verdict.size), "valid_decisions": int(valid.sum()),
              "errors": int((~valid).sum()), "correct_decisions": int(correct.sum()),
              "agreement_all_attempts": float(correct.mean()),
              "agreement_valid_decisions": float(correct.sum() / valid.sum()) if valid.any() else None,
              "negative_packets": int(negative[:, 0].sum()), "negative_attempts": int(negative.sum()),
              "false_approvals": int((approved & negative).sum()),
              "false_approve_rate": float((approved & negative).sum() / negative.sum()) if negative.any() else None,
              "false_rejections": int((rejected & positive).sum()),
              "false_reject_rate": float((rejected & positive).sum() / positive.sum()) if positive.any() else None,
              "majority_correct_packets": int((majority == expected[:, 0]).sum()),
              "majority_packet_agreement": float((majority == expected[:, 0]).mean()),
              "majority_ties_or_no_decision": int((majority < 0).sum()),
              "negative_packets_majority_approved": int(((majority == 1) & negative[:, 0]).sum()),
              "negative_packets_ever_approved": int((approved.any(axis=1) & negative[:, 0]).sum()),
              "mean_pairwise_flip_rate": float(np.nanmean(flips)) if np.isfinite(flips).any() else None,
              "observed_token_cost_estimate_usd": float(known_cost.sum()),
              "unknown_cost_components": int(np.isnan(costs).sum()),
              "fully_priced_attempts": int(complete_cost.sum()),
              "fully_priced_attempts_mean_usd": float(known_cost[complete_cost].mean()) if complete_cost.any() else None,
              "observed_usd_per_attempt": float(known_cost.mean()),
              "monotonic_latency_seconds": distribution(times.ravel().tolist()),
              "utc_latency_seconds": distribution(utc_times.ravel().tolist())}
    if autonomous is not None:
        result.update(jev_alone_attempts=int(autonomous.sum()), coverage=float(autonomous.mean()),
                      gpt_fallback_attempts=int((~autonomous).sum()),
                      jev_alone_false_approvals=int((approved & negative & autonomous).sum()))
        distributions["coverage"] = (weights @ autonomous.sum(axis=1)) / sums["attempts"]
    result["packet_bootstrap_95pct"] = {name: interval(values) for name, values in distributions.items()}
    return result, distributions


def evaluate(data, indices, threshold, protocol, seed):
    weights = bootstrap_weights(len(indices), protocol["bootstrap"]["repetitions"], seed)
    summaries, draws = {}, {}
    for backend in BACKENDS:
        summaries[backend], draws[backend] = arm_summary(
            data[backend][indices], data["expected"][indices], data[f"{backend}_estimated_usd"][indices, :, None],
            data[f"{backend}_elapsed_seconds"][indices], data[f"{backend}_utc_elapsed_seconds"][indices], weights)
    verdict, autonomous = route(data, threshold)
    fallback = ~autonomous
    costs = np.stack([data["jev_estimated_usd"], np.where(fallback, data["gpt_estimated_usd"], 0.)], axis=2)
    time = data["jev_elapsed_seconds"] + np.where(fallback, data["gpt_elapsed_seconds"], 0.)
    utc_time = data["jev_utc_elapsed_seconds"] + np.where(fallback, data["gpt_utc_elapsed_seconds"], 0.)
    summaries["cascade"], draws["cascade"] = arm_summary(verdict[indices], data["expected"][indices],
        costs[indices], time[indices], utc_time[indices], weights, autonomous[indices])
    differences = {}
    for left, right in (("gpt", "jev"), ("cascade", "gpt")):
        differences[f"{left}_minus_{right}"] = {
            name: {"estimate": summaries[left][name] - summaries[right][name],
                   "packet_bootstrap_95pct": interval(draws[left][name] - draws[right][name])}
            for name in ("agreement_all_attempts", "false_approve_rate", "observed_usd_per_attempt")}
    return {"arms": summaries, "paired_differences": differences}


def plot_curves(curves, selections, destination):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(2, 2, figsize=(13, 9), sharex=True, sharey=True, constrained_layout=True)
    for row, variant in enumerate(("original", "exclude_disputed")):
        for col, split in enumerate(("selection", "test")):
            ax = axes[row, col]
            points = curves[variant][split]
            coverage = [100 * p["coverage"] for p in points]
            ax.plot(coverage, [100 * p["jev_autonomous_false_approve_rate_all_negatives"] for p in points], label="Jev-only false approvals", color="#2563eb")
            ax.plot(coverage, [100 * p["cascade_false_approve_rate"] for p in points], label="Whole cascade", color="#b45309")
            ax.axhline(100 * points[0]["gpt_false_approve_rate"], color="#475569", ls="--", label="Recorded GPT")
            chosen = next(p for p in points if p["threshold"] == selections[variant]["cascade"]["threshold"])
            ax.scatter([100 * chosen["coverage"]], [100 * chosen["cascade_false_approve_rate"]], s=110, marker="*", color="#b45309", zorder=5)
            ax.set_title(("Original labels" if variant == "original" else "Two disputed packets excluded") + " · " + split)
            ax.set_xlabel("Attempts decided by Jev alone (%)")
            ax.set_ylabel("False approvals / all negative attempts (%)")
            ax.set_xlim(-2, 102)
            ax.set_ylim(bottom=-.4)
            ax.grid(alpha=.2)
    axes[0, 0].legend(fontsize=9)
    fig.suptitle("Confidence routing: 25 selection questions, 25 held-out questions\nStars use selection-fitted thresholds; test curves are descriptive, not retuned", fontsize=13)
    fig.savefig(destination.with_suffix(".svg"))
    fig.savefig(destination.with_suffix(".png"), dpi=160)
    plt.close(fig)


def main():
    global OUT
    protocol_path = OUT / "analysis-protocol.json"
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--from-paired", type=Path, help="Reproduce from the published paired-trial CSV without private receipts")
    parser.add_argument("--output", type=Path, default=OUT, help="Write derived outputs to a separate directory")
    args = parser.parse_args()
    OUT = args.output.resolve()
    OUT.mkdir(parents=True, exist_ok=True)
    manifest, truth, protocol = load(ROOT / "package/manifest.json"), load(ROOT / "ground_truth.json"), load(protocol_path)
    assert digest((ROOT / "package/manifest.json").read_bytes()) == protocol["manifest_sha256"]
    packets = metadata(manifest, truth, protocol)
    rows = read_paired(args.from_paired, packets, manifest["repetitions"]) if args.from_paired else read_receipts(packets, manifest, load(ROOT / "protocol.json"))
    data = arrays(rows, packets, manifest["repetitions"])
    packet_rows = packet_statistics(packets, data)
    write_csv(OUT / "per-packet.csv", packet_rows)
    save(OUT / "per-packet.json", packet_rows)
    curves, selections, results = {}, {}, {}
    curve_rows = []
    for variant_index, variant in enumerate(protocol["label_variants"]):
        eligible = np.array([variant == "original" or not p["disputed"] for p in packets])
        split_indices = {split: np.flatnonzero(eligible & np.array([split == "all" or p["split"] == split for p in packets]))
                         for split in ("selection", "test", "all")}
        selection = split_indices["selection"]
        thresholds = candidates(data["score"][selection], data["jev"][selection] >= 0)
        curves[variant] = {split: curve(data, indices, thresholds) for split, indices in split_indices.items()}
        selections[variant] = {"cascade": select_point(curves[variant]["selection"], "cascade_false_approvals"),
                               "jev_autonomous": select_point(curves[variant]["selection"], "jev_autonomous_false_approvals")}
        threshold = selections[variant]["cascade"]["threshold"]
        results[variant] = {}
        for split_index, (split, indices) in enumerate(split_indices.items()):
            results[variant][split] = evaluate(data, indices, threshold, protocol,
                protocol["bootstrap"]["seed"] + 100 * variant_index + split_index)
            curve_rows.extend({"label_variant": variant, "split": split, **point} for point in curves[variant][split])
    # Sensitivity at the unchanged primary threshold separates label exclusion from refitting.
    primary_threshold = selections["original"]["cascade"]["threshold"]
    fixed_primary = {}
    for split_index, split in enumerate(("selection", "test", "all")):
        indices = np.array([i for i, p in enumerate(packets) if not p["disputed"] and (split == "all" or p["split"] == split)])
        fixed_primary[split] = evaluate(data, indices, primary_threshold, protocol, protocol["bootstrap"]["seed"] + 200 + split_index)
    report = {"schema": 1, "new_provider_calls": 0, "protocol_sha256": digest(protocol_path.read_bytes()),
              "input_paired_csv_sha256": digest((args.from_paired or OUT / "paired-trials.csv").read_bytes()),
              "packet_count": len(packets), "paired_attempts": len(rows),
              "chosen_verdict_probability_below_half": int(((data["jev"] >= 0) & (data["score"] < .5)).sum()),
              "threshold_selections": selections, "results": results,
              "exclude_disputed_at_unchanged_primary_threshold": fixed_primary,
              "ci_note": "Packet-bootstrap 95% percentile intervals, 10000 resamples. No attempt-level independence assumption. Selected-threshold intervals hold the fitted threshold fixed; they do not include threshold-selection uncertainty.",
              "latency_note": "Sequential counterfactual sums of recorded service times; not a live cascade measurement. UTC estimates include the documented host sleep.",
              "cost_note": "Observed token-equivalent sums, with unknown components counted separately. Provider caching, workload and billing may differ in a deployed cascade; no new spend occurred."}
    save(OUT / "analysis.json", report)
    save(OUT / "threshold-curves.json", curves)
    write_csv(OUT / "threshold-curves.csv", curve_rows)
    plot_curves(curves, selections, OUT / "threshold-coverage")
    print(json.dumps({"packet_count": len(packets), "paired_attempts": len(rows), "new_provider_calls": 0,
                      "held_out": {variant: {"threshold": selections[variant]["cascade"]["threshold"],
                                             "arms": results[variant]["test"]["arms"]} for variant in results}}, indent=2))


if __name__ == "__main__":
    main()
