#!/usr/bin/env python3
"""Build an allowlisted publication with an external chart; never upload or call a judge."""
import base64
import hashlib
import importlib.metadata
import io
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

import markdown

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent


def load(path):
    return json.loads(path.read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


def pct(value):
    return f"{100 * value:.2f}%"


def ci(arm, metric):
    low, high = arm["packet_bootstrap_95pct"][metric]
    return f"{pct(arm[metric])} [{pct(low)}, {pct(high)}]"


def table(headers, rows):
    return "\n".join(["| " + " | ".join(headers) + " |", "| " + " | ".join(["---"] * len(headers)) + " |",
                      *["| " + " | ".join(map(str, row)) + " |" for row in rows]])


def post(report):
    full = report["results"]["original"]["all"]["arms"]
    sensitivity = report["results"]["exclude_disputed"]["all"]["arms"]
    test = report["results"]["original"]["test"]["arms"]
    clean_test = report["results"]["exclude_disputed"]["test"]["arms"]
    choices = report["threshold_selections"]
    threshold = choices["original"]["cascade"]["threshold"]
    saving = 1 - test["cascade"]["observed_token_cost_estimate_usd"] / test["gpt"]["observed_token_cost_estimate_usd"]
    packet_table = table(["Judge", "Majority correct / packets", "Negative packets majority-approved", "Negative packets ever-approved", "Mean pairwise flip rate"],
        [[name, f"{arm['majority_correct_packets']}/{arm['packets']}",
          f"{arm['negative_packets_majority_approved']}/{arm['negative_packets']}",
          f"{arm['negative_packets_ever_approved']}/{arm['negative_packets']}",
          ci(arm, "mean_pairwise_flip_rate")] for name, arm in (("Jev", full["jev"]), ("GPT", full["gpt"]))])
    sensitivity_table = table(["Labels", "Judge", "Agreement incl. errors [95% CI]", "False approves / negative attempts", "Negative packets majority-approved", "Majority correct"],
        [[variant, name, ci(arm, "agreement_all_attempts"), f"{arm['false_approvals']}/{arm['negative_attempts']}",
          f"{arm['negative_packets_majority_approved']}/{arm['negative_packets']}", f"{arm['majority_correct_packets']}/{arm['packets']}"]
         for variant, arms in (("Original", full), ("Two disputed packets excluded", sensitivity))
         for name, arm in (("Jev", arms["jev"]), ("GPT", arms["gpt"]))])
    heldout_table = table(["Policy", "Agreement incl. errors [95% CI]", "False approves / 2,400 negatives", "Observed token-cost estimate", "Unknown-cost components", "Latency p50 / p95"],
        [[name, ci(arm, "agreement_all_attempts"), str(arm["false_approvals"]),
          f"${arm['observed_token_cost_estimate_usd']:.4f}", arm["unknown_cost_components"],
          f"{arm['monotonic_latency_seconds']['p50']:.3f} / {arm['monotonic_latency_seconds']['p95']:.3f} s"]
         for name, arm in (("Jev only", test["jev"]), ("GPT only", test["gpt"]), ("Cascade", test["cascade"]))])
    clean_table = table(["Policy", "Agreement incl. errors [95% CI]", "False approves / 2,300 negatives", "Observed token-cost estimate", "Unknown-cost components"],
        [[name, ci(arm, "agreement_all_attempts"), arm["false_approvals"], f"${arm['observed_token_cost_estimate_usd']:.4f}", arm["unknown_cost_components"]]
         for name, arm in (("Jev only", clean_test["jev"]), ("GPT only", clean_test["gpt"]), ("Cascade", clean_test["cascade"]))])
    price_table = table(["Judge / token type", "USD per million", "USD per token"], [
        ["Jev input (flat, including any unreported cache use)", "$0.042", "$0.000000042"],
        ["Jev output", "$0", "$0"], ["GPT fresh input", "$4", "$0.000004"],
        ["GPT cached input", "$0.40", "$0.0000004"], ["GPT output, including reasoning", "$20", "$0.00002"]])
    return f"""# Can Jev screen proposals before a GPT judge?

## Result: lower simulated cost, but GPT-level false-approval risk did not hold out

A threshold selected on 25 questions let Jev decide **{pct(test['cascade']['coverage'])}** of attempts on the other 25 questions. The observed token-equivalent cost estimate fell **{pct(saving)}**, from **${test['gpt']['observed_token_cost_estimate_usd']:.4f}** to **${test['cascade']['observed_token_cost_estimate_usd']:.4f}**. But false approvals rose from **{test['gpt']['false_approvals']} to {test['cascade']['false_approvals']}**. Excluding the disputed held-out packet leaves **{clean_test['gpt']['false_approvals']} for GPT versus {clean_test['cascade']['false_approvals']} for the cascade**.

This does not establish a GPT-safety-equivalent cheaper gate. It is an offline, post-hoc routing simulation on a small curated packet set, not a deployed cascade or a coding-success benchmark. All costs below are usage-based estimates, not invoices. **This reanalysis made zero new Jev or GPT calls.**

**Verdict:** GPT stays the gate. At this threshold, Jev is not a safe pre-screen.

## What was measured

The original comparison used **50 SWE-bench Verified questions, 99 authored proposal packets, and 100 repeats per packet per judge**: 9,900 attempts each for Jev `1.13.0` and GPT `5.6-sol` with high reasoning. There are **50 positive-labelled and 49 negative-labelled packets**, not 9,900 independent bugs. Questions were curated for small single-Python-file reference repairs across eleven repositories; they were not a population sample.

All original inputs, labels and receipts remain unchanged. Every one of Jev's **9,899 successful responses** retained `answers.permission.probabilities` and `confidence`. The one DNS failure had no provider response; it remains an error and was not rerun. GPT's 18 original request errors also remain in the data. `paired-trials.csv` exposes the probabilities, confidence, paired verdicts, usage, costs and both clocks needed to reproduce this analysis without private logs.

## Per-packet repeatability

{packet_table}

`per-packet.csv` contains all 99 packets and both judges. Majority uses valid decisions only. A 50/50 tie is explicitly `tie`, not silently approved or rejected; one Jev packet ties. Ties/no-decision packets do not count as majority-correct. “Ever-approved” means at least one valid approval among repeats.

The primary flip rate is the probability that two distinct valid repeats disagree: **2 × approvals × rejections / [n × (n − 1)]**. The table also exports the minority fraction and chronological adjacent-repeat flip rate, skipping error-adjacent pairs rather than bridging across errors. Repeated confidence or verdict consistency is not evidence of correctness.

Confidence intervals use **10,000 packet-bootstrap resamples**, retaining all 100 paired repeats when a packet is sampled. Judges and cascade differences use the same resample weights. They do not treat repeated attempts as independent questions. These are percentile intervals, not a non-inferiority test; packets within the same question may still be correlated.

## Label sensitivity for both judges

{sensitivity_table}

The exclusions are q29/stage1 (`pylint-6903`, `_cpu_count`) and q08/stage1 (`django-15127`, `get_level_tags`). Their source citations are false, but the proposed locations may still support alternative repairs. The Pylint alternative was demonstrated in memory; the Django lifecycle alternative was not runtime-validated. Exclusion is an explicit post-hoc sensitivity, not a replacement ground truth. Other alternative repairs were not exhaustively ruled out.

These metrics are **agreement with frozen authored labels**, not pure wrong-location detection or real repair correctness. GPT's zero false approvals after exclusion produce a degenerate empirical packet-bootstrap interval of [0, 0]. That does **not** prove zero population risk; there are only 47 negative packets overall and 23 in the reduced held-out set.

## Question-disjoint threshold selection

Before fitting this reanalysis, `analysis-protocol.json` froze a deterministic SHA-256 split: **25 selection questions / 50 packets**, and **25 test questions / 49 packets**. All stages and repeats of a question stay together. The split seed is `jev-q50-offline-cascade-2026-09-27-v1`; ranking uses SHA-256(seed + `:` + instance ID). No test probability, verdict or label enters candidate generation or threshold selection.

This is **not a prospectively unseen benchmark**: original aggregate and packet findings had already been inspected before the new split. The split prevents direct test-set threshold tuning now; it cannot undo prior exposure. The test curves are descriptive and were not used to retune the selected threshold.

The routing score is the probability assigned to **Jev's recorded native verdict**, `probabilities[choice]`. A successful Jev decision is accepted when its score is at least the threshold; otherwise the cascade uses GPT's recorded decision for **that exact packet and repeat**. The separate `confidence` field is published but not used. Neither field is assumed to be a calibrated probability of correctness. Both confident approvals and confident rejections can bypass GPT.

Candidate thresholds are selection-set score boundaries and their next representable floats, plus 0.5, 1 and an all-defer value above 1. We choose the threshold with greatest Jev-alone coverage subject to **the whole cascade's selection-set false approvals being no greater than GPT's**; equal-coverage ties choose the larger threshold. The all-defer candidate reproduces GPT decisions, but still includes the wasted Jev call in simulated cost and time.

With original labels, a looser threshold **{choices['original']['jev_autonomous']['threshold']:.2f}** makes Jev's *own* autonomous false-approval contribution **{pct(choices['original']['jev_autonomous']['jev_autonomous_false_approve_rate_all_negatives'])}**, below GPT's **{pct(choices['original']['jev_autonomous']['gpt_false_approve_rate'])}**, at **{pct(choices['original']['jev_autonomous']['coverage'])}** coverage. But the **whole cascade** then reaches **{pct(choices['original']['jev_autonomous']['cascade_false_approve_rate'])}** because GPT can add errors on deferred cases. Matching only Jev's contribution is insufficient.

The whole-cascade rule instead selects **{threshold:.2f}**, with **{pct(choices['original']['cascade']['coverage'])}** selection coverage. Independently applying the same rule after excluding the disputed selection packet also selects **{choices['exclude_disputed']['cascade']['threshold']:.2f}**. The machine-readable output includes exclusion sensitivity at the unchanged primary threshold as well as the separately fitted sensitivity.

![False-approval rate versus Jev-alone coverage](threshold-coverage.png)

Bottom panels: the blue line sits under the orange one, since GPT adds zero false approves there.

Blue: Jev's autonomous false approvals divided by **all negative attempts**. Orange: all cascade false approvals. Dashed: recorded GPT. Stars use the selection-fitted threshold {threshold:.2f}. The CSV also reports the conditional rate among autonomously decided negatives; its denominator is different. “Coverage” means fraction of **packet-repeat attempts**, not fraction of distinct questions. All thresholds and denominators are in `threshold-curves.csv`.

## Held-out results: 4,900 paired attempts on 25 questions

{heldout_table}

The cascade's held-out false-approval rate is **{ci(test['cascade'], 'false_approve_rate')}**, versus **{ci(test['gpt'], 'false_approve_rate')}** for GPT. Its error count is **{test['cascade']['errors']}**, versus **{test['gpt']['errors']}** for GPT. Paired packet-bootstrap differences, coverage intervals, false rejections, majority verdicts and mean-latency intervals are in `analysis.json`. Intervals hold the fitted threshold fixed; they do not include threshold-selection uncertainty. Latency p50/p95 values are point estimates, not bootstrap intervals.

### Same held-out evaluation after excluding the disputed Django packet

{clean_table}

The threshold remains {threshold:.2f}, and coverage is **{pct(clean_test['cascade']['coverage'])}**. The remaining 14 cascade false approvals are concentrated in one other packet. This reduced-label evaluation still does not meet GPT's observed zero-false-approval result.

## Cost and latency accounting

{price_table}

These are the **frozen experiment tariffs**, not a claim about current list prices. GPT `output_tokens` already includes reasoning tokens, so reasoning is charged **once**, not added again. Provider-reported cached input receives the $0.40/M rate; **61.26% of original GPT input tokens were reported cached**. A fresh session and cache key did not imply zero provider cache hits. Jev's cached/reasoning token details were not reported; missing details are not evidence of zero internal cache or reasoning.

Original observed token estimates were **$1.684814 Jev** and **$91.271018 GPT**. Those were estimates for the recorded usage, not certified payments; GPT used the existing OAuth-backed provider. All 19 original errors lack usage. Missing usage remains **unknown, not zero**.

Simulation always includes Jev's recorded usage, then includes GPT usage only on fallback. Totals sum known components and report unknown components separately; `fully_priced_attempts` and their mean cost are also exported. This is **counterfactual token-equivalent cost**, not new spend or a guaranteed deployed bill. Selective requests could change cache hits, batching and service behavior.

Cascade latency is **recorded Jev duration + recorded GPT duration on fallback**, or Jev duration alone otherwise. Original paired requests ran concurrently; these sums simulate sequential routing and were not observed end-to-end. Primary tables use the original monotonic clock. UTC-derived distributions are also exported: a confirmed 929-second host sleep overlapped ten original requests, including all eight GPT socket timeouts, and most sleep was excluded by the host's monotonic clock. Those failures cannot be attributed solely to GPT reliability.

## Who made the proposals and labels?

The authoring assistant's **recorded model ID was `openai-codex/gpt-6-astra`**. Retained structured session records identify its annotation-writing tool calls on 2026-09-19; `provenance.json` preserves the narrow, non-secret evidence.

`build_package.py` deterministically constructs the proposal packets from those annotations and commit-pinned source. Positive proposals use selected reference-repair locations. Negatives place a real source quotation at a decoy location or assert a fabricated source-level execution trace; the supplied host-read source itself remains authentic. These are **synthetic authored proposals**, not a sample of mistakes naturally made by live coding investigators.

The same builder assigns the final stage `approved` and earlier stages `disapproved`. The labels were frozen before judge inference, using authored explanations, baseline source and reference repair/test diffs. Reference regression suites were **not executed** to validate these packet labels. There is **no recorded independent blinded human annotation pass**. Human validation of the underlying SWE-bench Verified issues is a different claim.

**Disclosure correction:** the frozen `ground_truth.json` says “Human causal annotations.” The retained session shows assistant-authored annotations; that wording must not be presented as proof of independent human labelling. We preserve the original file for audit and correct its interpretation here. The authoring assistant and GPT judge are both OpenAI-family models, so possible author/judge alignment is another unmeasured limitation.

## Exact backend mapping and why Sol high

Both backends receive the same complete packet: `questions.permission` contains the identical instructions and approved/disapproved criteria; `state` contains the original issue, diagnosis, intended locations, source evidence and provenance. Expected labels and prior-stage verdicts are not sent.

* **Jev:** POST the packet object plus `model: jev-1.13.0` to `https://api.typesafe.ai/v1/systemone`. Its binary question ID is `permission`. The archive contains the exact stable request body for all 99 packets under `prompts/jev/`.
* **GPT:** use `model: gpt-5.6-sol`, `reasoning.effort: high`, no tools, `store: false`, streaming, and the fixed top-level instructions from `protocol.json`. The user text is exactly `Decision packet:\\n` + the original packet JSON bytes + `\\n\\n` + the fixed verdict-only deliverable. The archive contains all stable request fields and exact prompt text under `prompts/gpt/`. Only per-call UUID cache/session metadata is omitted; the original collector generates it afresh. These are request templates, not a claim that provider-native interfaces are identical.

The fifty-question experiment **retained Sol high from the preceding twenty-question live gate comparison**. [INFERENCE] Continuity of the comparator is the supported operational explanation; no separate model/effort selection study or independent rationale was retained. It is not evidence that high reasoning was necessary, cost-optimal or the fairest matched-budget gate. **Terra/Luna or another low-reasoning comparator was not run**; no claim about those operating points is made.

## Reproduce without credentials or network

Unpack `jev-q50-reanalysis.zip`, then run:

```sh
uv run --with-requirements reanalysis/requirements.txt python reanalysis/analyze.py \\
  --from-paired reanalysis/paired-trials.csv --output reproduced
uv run --with-requirements reanalysis/requirements.txt python -m unittest discover \\
  -s reanalysis -p test_analysis.py
```

The commands above do not call a provider. Installing dependencies may require network once; the analysis itself does not. The original collector is included for transparency, **not invoked by reproduction**. Do not run it to replay scored calls.

The archive contains all **99 original packets**, all **198 backend prompt mappings**, the **65 referenced source files**, frozen controls/annotations/labels, sanitized paired trial data, analysis and construction code, tests, exact dependency versions, charts, this post and a SHA-256 inventory. Raw conversations, credentials, authorization headers, native databases and raw provider-response logs are excluded. `input-receipt-sha256.json` is a private audit binding and is not required by the public reproduction.

## Sources and reuse

The underlying issue dataset is [SWE-bench Verified](https://huggingface.co/datasets/SWE-bench/SWE-bench_Verified). Source provenance retains repository, exact base commit, original raw-source URL and hash. The bundle carries **89 upstream license/notice files**, including primary notices at all 50 selected source revisions, in `reanalysis/upstream-licenses/` with an explicit manifest. Upstream material retains its own licenses; public availability is not blanket permission to relicense all packets under one license. No blanket relicensing is asserted for this mixed corpus.

The complete numerical results, not a selected best-of run, are preserved. No labels were rewritten, no failed trial was retried, no GPT calls were added, and no optional comparator was run.
"""


def main():
    report = load(OUT / "analysis.json")
    notices = load(OUT / "upstream-license-manifest.json")
    if notices["unresolved"]:
        raise ValueError("Unresolved upstream notices")
    article = post(report)
    (OUT / "post.md").write_text(article)
    versions = {name: importlib.metadata.version(name) for name in ("numpy", "matplotlib", "Markdown")}
    (OUT / "requirements.txt").write_text("".join(f"{name}=={version}\n" for name, version in versions.items()))
    manifest, provider = load(ROOT / "package/manifest.json"), load(ROOT / "protocol.json")
    members = {}

    def add(relative, expected=None):
        path = PurePosixPath(relative)
        if path.is_absolute() or ".." in path.parts:
            raise ValueError("Unsafe publication member")
        source = ROOT / relative
        if source.is_symlink() or not source.resolve().is_relative_to(ROOT):
            raise ValueError("Publication member escapes the calibration root")
        data = source.read_bytes()
        if expected is not None and sha(data) != expected:
            raise ValueError("Source hash changed: " + relative)
        members[relative] = data

    for name in ("package/manifest.json", "protocol.json", "questions.json", "ground_truth.json", "annotations.json",
                 "selection.json", "source-index.json", "support-source-index.json", "build_package.py", "fetch_sources.py", "run.py", "score.py"):
        add(name, manifest["input_sha256"].get(name))
    source_records = load(ROOT / "source-index.json") + load(ROOT / "support-source-index.json")
    source_paths = set()
    for source in source_records:
        add(source["source_file"], source["sha256"])
        source_paths.add(source["source_file"])
    if len(source_paths) != 65:
        raise ValueError("Unexpected source snapshot count")
    prompt_hashes = []
    for case in manifest["cases"]:
        for proposal in case["proposals"]:
            add(proposal["path"], proposal["packet_id"])
            raw = members[proposal["path"]]
            packet = json.loads(raw)
            bodies = {"jev": {**packet, "model": provider["jev"]["model"]},
                      "gpt": {"model": provider["gpt"]["model"], "instructions": provider["gpt"]["instructions"],
                              "input": [{"role": "user", "content": [{"type": "input_text", "text":
                                  "Decision packet:\n" + raw.decode() + "\n\n" + provider["gpt"]["deliverable"]}]}],
                              "tools": [], "store": False, "stream": True,
                              "reasoning": {"effort": provider["gpt"]["reasoning_effort"], "summary": "auto"}}}
            for backend, body in bodies.items():
                relative = f"prompts/{backend}/{proposal['packet_id']}.json"
                members[relative] = canonical(body)
                prompt_hashes.append({"packet_id": proposal["packet_id"], "backend": backend, "path": relative,
                                      "sha256": sha(members[relative])})
    members["prompts/manifest.json"] = (json.dumps({"schema": 1, "mappings": prompt_hashes,
        "gpt_omitted_transport_metadata": ["prompt_cache_key (fresh request UUID)", "HTTP session_id", "HTTP conversation_id", "authorization headers"]}, indent=2) + "\n").encode()
    for name in ("analysis-protocol.json", "probability-coverage-summary.json", "provenance.json", "paired-trials.csv",
                 "per-packet.csv", "per-packet.json", "threshold-curves.csv", "threshold-curves.json", "analysis.json",
                 "threshold-coverage.png", "threshold-coverage.svg", "analyze.py", "test_analysis.py", "publish.py",
                 "post.md", "requirements.txt", "upstream-license-manifest.json"):
        add("reanalysis/" + name)
    for notice in notices["notices"]:
        add("reanalysis/" + notice["local_path"], notice["sha256"])
    # This is deliberately an allowlist, not a directory archive of private receipts.
    forbidden = re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\b(?:sk-proj-|sk-ant-api)[A-Za-z0-9_-]{20,}|Bearer [A-Za-z0-9_.-]{24,}|\"access_token\"\s*:\s*\"[^\"]{20,}\"")
    for name, data in members.items():
        if name.endswith((".py", ".json", ".md", ".csv", ".txt")) and forbidden.search(data):
            raise ValueError("Potential credential in publication member: " + name)
    checksums = {name: sha(data) for name, data in sorted(members.items())}
    members["SHA256SUMS.json"] = (json.dumps(checksums, indent=2) + "\n").encode()
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(members.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 9, 27, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    bundle = stream.getvalue()
    (OUT / "jev-q50-reanalysis.zip").write_bytes(bundle)
    body = markdown.markdown(article, extensions=["tables", "fenced_code"])
    image_path = Path("images/image-01.png")
    (OUT / image_path.parent).mkdir(exist_ok=True)
    (OUT / image_path).write_bytes((OUT / "threshold-coverage.png").read_bytes())
    body = body.replace('src="threshold-coverage.png"', f'src="{image_path.as_posix()}"')
    bundle64 = base64.b64encode(bundle).decode()
    document = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Jev → GPT: packet-level reanalysis and held-out cascade</title>
<style>body{{max-width:1100px;margin:40px auto;padding:0 22px;color:#172033;background:#fff;font:17px/1.6 system-ui,sans-serif}}h1,h2,h3{{line-height:1.2}}h1{{font-size:2.1rem}}h2{{margin-top:2.4rem}}table{{border-collapse:collapse;width:100%;font-size:.86rem;display:block;overflow-x:auto}}th,td{{border:1px solid #cbd5e1;padding:.55rem;text-align:left}}th{{background:#f1f5f9}}img{{max-width:100%;height:auto}}code,pre{{font-family:ui-monospace,monospace;font-size:.9em}}pre{{overflow:auto;background:#f1f5f9;padding:16px}}a{{color:#1d4ed8}}.download{{display:inline-block;padding:12px 18px;background:#172033;color:white;border-radius:5px;text-decoration:none}}.metadata{{font-size:.85rem;color:#475569;overflow-wrap:anywhere}}.correction{{margin-bottom:24px;padding:16px 18px;border:1px solid #fcd34d;border-left:4px solid #d97706;border-radius:5px;background:#fffbeb}}@media(max-width:600px){{body{{margin:20px auto;font-size:16px}}h1{{font-size:1.7rem}}}}</style></head>
<body><aside class="correction" role="note"><strong>Correction:</strong> labels were written by an AI assistant (<code>gpt-6-astra</code>), not humans. <code>ground_truth.json</code> says "Human causal annotations"; that wording is wrong. Details below.</aside>
<a class="download" id="download-bundle" download="jev-q50-reanalysis.zip" href="data:application/zip;base64,{bundle64}">Download all packets, prompts, data and code</a>
<p class="metadata">Bundle SHA-256: <code id="bundle-sha256">{sha(bundle)}</code><br>{len(bundle):,} bytes · {len(members)} files · no new model calls</p>
<main>{body}</main></body></html>"""
    (OUT / "index.html").write_text(document)
    publication = {"schema": 1, "status": "built_locally_not_uploaded", "bundle": "jev-q50-reanalysis.zip",
                   "bundle_sha256": sha(bundle), "bundle_bytes": len(bundle), "html_sha256": sha(document.encode()),
                   "member_count": len(members), "packets": 99, "backend_prompt_mappings": len(prompt_hashes),
                   "source_snapshots": len(source_paths), "upstream_notices": len(notices["notices"]),
                   "dependency_versions": versions, "new_provider_calls": 0,
                   "privacy": "Explicit file allowlist; no raw receipts, sessions, native databases, credentials or authorization headers. Credential-pattern scan passed; it is not a general proof against every possible secret."}
    (OUT / "publication.json").write_text(json.dumps(publication, indent=2) + "\n")
    print(json.dumps(publication, indent=2))


if __name__ == "__main__":
    main()
