"""Consumer-visible statistical and routing boundaries; no provider calls."""
import unittest

import numpy as np

import analyze as a


class RoutingTests(unittest.TestCase):
    def test_confidence_boundary_and_paired_errors(self):
        data = {"jev": np.array([[1, 0, -1, -1]]),
                "gpt": np.array([[0, 1, 0, -1]]),
                "score": np.array([[.89, np.nextafter(.89, 0), np.nan, np.nan]])}
        verdict, autonomous = a.route(data, .89)
        np.testing.assert_array_equal(verdict, [[1, 1, 0, -1]])
        np.testing.assert_array_equal(autonomous, [[True, False, False, False]])

    def test_matching_jev_only_false_approvals_does_not_match_the_cascade(self):
        data = {"jev": np.array([[1, 0], [0, 0]]),
                "gpt": np.array([[0, 0], [1, 0]]),
                "score": np.array([[.8, .95], [.6, .95]]),
                "expected": np.array([[0], [0]])}
        points = a.curve(data, np.array([0, 1]), [.7, .9, np.nextafter(1., np.inf)])
        standalone = a.select_point(points, "jev_autonomous_false_approvals")
        cascade = a.select_point(points, "cascade_false_approvals")
        self.assertEqual(standalone["threshold"], .7)
        self.assertEqual(standalone["cascade_false_approvals"], 2)
        self.assertEqual(cascade["threshold"], .9)
        self.assertEqual(cascade["cascade_false_approvals"], 1)
        self.assertEqual(points[-1]["cascade_false_approvals"], points[-1]["gpt_false_approvals"])

    def test_test_probabilities_and_labels_do_not_enter_selection(self):
        data = {"jev": np.array([[1, 0], [0, 1]]),
                "gpt": np.array([[0, 0], [1, 1]]),
                "score": np.array([[.8, .95], [.99, .99]]),
                "expected": np.array([[0], [1]])}
        selection = np.array([0])
        def fit():
            thresholds = a.candidates(data["score"][selection], data["jev"][selection] >= 0)
            return a.select_point(a.curve(data, selection, thresholds), "cascade_false_approvals")
        original = fit()
        data["score"][1] = [.50001, 1.]
        data["expected"][1] = 0
        data["gpt"][1] = [-1, 0]
        self.assertEqual(fit(), original)


class PacketStatisticsTests(unittest.TestCase):
    def test_ties_errors_and_distinct_repeat_flip_probability(self):
        packets = [{"packet_id": "p", "expected_verdict": "approved"}]
        data = {backend: np.array([[1, -1, 0, 1, 0]]) for backend in a.BACKENDS}
        data.update(jev_p_approve=np.array([[.7, np.nan, .2, .9, .4]]),
                    jev_confidence=np.array([[.4, np.nan, .6, .8, .2]]))
        row = a.packet_statistics(packets, data)[0]
        self.assertEqual(row["jev_majority"], "tie")
        self.assertFalse(row["jev_majority_correct"])
        self.assertEqual(row["jev_errors"], 1)
        self.assertEqual(row["jev_minority_fraction_valid"], .5)
        self.assertAlmostEqual(row["jev_pairwise_flip_rate"], 2 / 3)
        self.assertEqual(row["jev_adjacent_valid_pairs"], 2)
        self.assertEqual(row["jev_adjacent_flip_rate"], 1.)

    def test_bootstrap_keeps_all_repeats_of_a_packet_together(self):
        verdict = np.array([[0] * 100, [1] * 100])
        weights = a.bootstrap_weights(2, 1000, 20260927)
        summary, draws = a.arm_summary(verdict, np.array([[0], [0]]),
            np.zeros((2, 100, 1)), np.ones((2, 100)), np.ones((2, 100)), weights)
        self.assertEqual(summary["agreement_all_attempts"], .5)
        self.assertEqual(summary["packet_bootstrap_95pct"]["agreement_all_attempts"], [0., 1.])
        self.assertEqual(set(draws["agreement_all_attempts"]), {0., .5, 1.})

    def test_unknown_cost_remains_unknown_and_errors_are_not_rejections(self):
        summary, _ = a.arm_summary(np.array([[1, -1]]), np.array([[1]]),
            np.array([[[.1, 0.], [np.nan, .2]]]), np.array([[1., 3.]]),
            np.array([[1., 3.]]), a.bootstrap_weights(1, 100, 42))
        self.assertEqual(summary["errors"], 1)
        self.assertEqual(summary["false_rejections"], 0)
        self.assertEqual(summary["unknown_cost_components"], 1)
        self.assertEqual(summary["fully_priced_attempts"], 1)
        self.assertAlmostEqual(summary["observed_token_cost_estimate_usd"], .3)


if __name__ == "__main__":
    unittest.main()
