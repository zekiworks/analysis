#!/usr/bin/env python3
"""Collect and verify pre-repair source for the frozen-proposal calibration."""
import argparse
import ast
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parent
HUNK = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(.*)$")
MAX_SOURCE_BYTES = 2 * 1024 * 1024


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.chmod(0o600)
    temporary.replace(path)


def parse_hunks(patch):
    hunks = []
    current = None
    for line in patch.splitlines():
        match = HUNK.match(line)
        if match:
            current = {"start": int(match[1]), "count": int(match[2] or 1),
                       "header": match[5].strip(), "old_lines": [], "changed_old_lines": [],
                       "added_lines": [], "removed_lines": []}
            hunks.append(current)
        elif current is not None and line.startswith((" ", "-", "+")):
            if line.startswith(("---", "+++")):
                raise ValueError("Expected a single-file reference patch")
            if line[0] == "-":
                current["changed_old_lines"].append(current["start"] + len(current["old_lines"]))
                current["removed_lines"].append(line[1:])
            elif line[0] == "+":
                current["changed_old_lines"].append(current["start"] + len(current["old_lines"]))
                current["added_lines"].append(line[1:])
            if line[0] != "+":
                current["old_lines"].append(line[1:])
    if not hunks or any(len(hunk["old_lines"]) != hunk["count"] for hunk in hunks):
        raise ValueError("Reference patch hunk lengths are inconsistent")
    return hunks


def definitions(source):
    found = []

    class Visitor(ast.NodeVisitor):
        def __init__(self):
            self.parents = []

        def visit_definition(self, node):
            name = ".".join(self.parents + [node.name])
            start = min([node.lineno] + [item.lineno for item in node.decorator_list])
            found.append({"name": name, "kind": type(node).__name__, "start": start,
                          "definition_line": node.lineno, "end": node.end_lineno})
            self.parents.append(node.name)
            self.generic_visit(node)
            self.parents.pop()

        visit_ClassDef = visit_definition
        visit_FunctionDef = visit_definition
        visit_AsyncFunctionDef = visit_definition

    Visitor().visit(ast.parse(source))
    return found


def fetch(case, source_path=None):
    relative = PurePosixPath(source_path or case["source_path"])
    if relative.is_absolute() or ".." in relative.parts or relative.suffix != ".py":
        raise ValueError("Source path must be a relative Python path")
    if not re.fullmatch(r"[0-9a-f]{40}", case["base_commit"]):
        raise ValueError("Source revision must be a full commit hash")
    destination = ROOT / "sources" / case["instance_id"] / relative
    url = "https://raw.githubusercontent.com/" + case["repo"] + "/" + case["base_commit"] + "/" + urllib.parse.quote(str(relative), safe="/")
    if destination.is_file():
        data = destination.read_bytes()
    else:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
        request = urllib.request.Request(url, headers={"User-Agent": "swebench-judge-calibration-source-collector"})
        with opener.open(request, timeout=60) as response:
            data = response.read(MAX_SOURCE_BYTES + 1)
        if len(data) > MAX_SOURCE_BYTES:
            raise ValueError("Source exceeds the collection bound")
    source = data.decode("utf-8")
    lines = source.splitlines()
    hunks = parse_hunks(case["patch"]) if source_path is None else []
    for hunk in hunks:
        offset = hunk["start"] - 1 if hunk["count"] else hunk["start"]
        if lines[offset:offset + hunk["count"]] != hunk["old_lines"]:
            raise ValueError("Reference patch does not match the commit-pinned source: " + case["instance_id"])
    definition_error = None
    try:
        source_definitions = definitions(source)
    except SyntaxError as error:
        source_definitions = []
        definition_error = f"{error.msg} at line {error.lineno}"
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not destination.is_file():
        destination.write_bytes(data)
        destination.chmod(0o600)
    result = {"instance_id": case["instance_id"], "path": str(relative),
              "base_commit": case["base_commit"], "url": url,
              "source_file": str(destination.relative_to(ROOT)),
              "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data),
              "total_lines": len(lines),
              "reference_patch_matches_source": True if source_path is None else None,
              "hunks": hunks, "definitions": source_definitions,
              "definition_parse_error": definition_error}
    metadata = (ROOT / "source-metadata" / (case["instance_id"] + ".json")
                if source_path is None else
                ROOT / "support-metadata" / case["instance_id"] / (str(relative) + ".json"))
    save(metadata, result)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--support", action="store_true")
    args = parser.parse_args()
    selection = json.loads((ROOT / "selection.json").read_text())
    if selection["status"] != "source-curation":
        raise SystemExit("Refusing to change sources after package freezing")
    jobs = [(case, None) for case in selection["cases"]]
    if args.support:
        annotations = json.loads((ROOT / "annotations.json").read_text())
        jobs = [(case, path) for case in selection["cases"]
                for path in sorted({item["path"] for item in
                                    annotations.get(case["instance_id"], {}).get("support_sources", [])})]
    results = []
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {pool.submit(fetch, case, path): (case["instance_id"], path)
                   for case, path in jobs}
        for future in as_completed(futures):
            result = future.result()
            results.append(result)
            print(result["instance_id"], result["path"], result["bytes"], "bytes",
                  "SOURCE_OK" if args.support else "REFERENCE_CONTEXT_OK", flush=True)
    index_name = "support-source-index.json" if args.support else "source-index.json"
    save(ROOT / index_name, sorted(results, key=lambda item: (item["instance_id"], item["path"])))
    print("COMMIT_PINNED_SOURCES_OK", len(results), flush=True)


if __name__ == "__main__":
    main()
